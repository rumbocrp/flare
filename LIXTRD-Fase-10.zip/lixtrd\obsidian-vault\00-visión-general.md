# 00 - Visión General del Proyecto LIXTRD Mark II

## Objeto

Plataforma de trading multi-activo hecho a mano, mejorado y expandido desde el repositorio original rumbocrp/LIXTRD.

## Alcance Inicial

- Stack base: React + Vite + TypeScript (frente)
- Backend: Python con módulos de trading
- Base de datos: SQLite para auditoría
- Tema visual: Matrix Green (verde Matrix)
- Nav móvil: barra inferior ultra-compacta
- Módulos por implementar: criptomonedas, memecoins, futuros, índices, metales

## Stack Tecnológico

### Frontend

- React 18+ with TypeScript
- Vite 5+ para build rápido
- React Router para navegación
- CSS personalizado con tema Matrix Green

### Backend

- Python 3.11+
- Yahoo Finance API (velas reales)
- Binance WebSocket (crypto)
- Futures data providers
- SQLite con auditoría completa

### Despliegue

- Vite build de producción
- Variables de entorno .env
- Contenedores Docker (opcional)
- HTTPS para APIs financieras

## Filosofía de Desarrollo

Hecho a mano, mejorado y expandido

A diferencia del repo original que es un sistema listo para usar, LIXTRD Mark II será:

1. Hecho a mano: Cada línea de código, cada estilo CSS, cada decisión de UI será revisada y mejorada.
2. Mejorado: Matrix Green theme, nav móvil compacta, mejor DX.
3. Expandido: Soporta activos que el original no tocaba: memecoins, metales precious, futuros diversificados.

## Estructura del Vault Obsidian

obsidian-vault/

├── 00-visión-general.md
├── 01-arquitectura.md
├── 02-tema-matrix.md
├── 03-nav-movil.md
├── 04-datos.md
├── 05-motor-señales.md
├── 06-dashboard.md
├── 07-riesgo-auditoria.md
├── 08-memecoins.md
├── 09-futuros-indices.md
├── 10-metales.md
├── 11-despliegue.md
├── 12-roadmap.md
└── README.md

## Próximos Pasos Inmediatos

1. Clonar el repositorio original: git clone https://github.com/rumbocrp/LIXTRD.git
2. Abrir Obsidian y apuntar a: C:\Users\Bitbase\OneDrive\Documents\BITBASE\FLARE\lixtrd\obsidian-vault
3. Empezar por la sesión 00: 00-visión-general.md
4. Aplicar la guía LEGO de tema y nav (vista previa en npm run dev)