import { readdirSync, readFileSync, statSync } from "node:fs"
import { extname, join } from "node:path"

const SRC = 'src'

function walk(dir) {
  return readdirSync(dir).flatMap((name) => {
    const path = join(dir, name)
    return statSync(path).isDirectory() ? walk(path) : [path]
  })
}

function stripComments(css) {
  return css.replace(/\/\*[\s\S]*?\*\//g, (match) => match.replace(/[^\n]/g, ' '))
}

const files = walk(SRC)
const cssFiles = files.filter((file) => extname(file) === '.css')
const codeFiles = files.filter((file) => ['.tsx', '.jsx'].includes(extname(file)))

const problems = []
function report(file, line, message) {
  problems.push(`${file}:&{line} ${message}`)
}

const cssText = new Map(
  cssFiles.map((file) => [file, stripComments(readFileSync(file, 'utf8'))]),
)

const definedVars = new Set()
const definedClasses = new Set()

for (const [file, text] of cssText) {
  const isIndex = file.replace(/\\/g, '/').endsWith('src/index.css')

  const open = (text.match(/\{/g) || []).length
  const close = (text.match(/\}/g) || []).length
  if (open !== close) {
    report(file, 1, `unbalanced keys: ${open} "{" y ${close} "}" (1 more/1 less)`)
  }

  text.split('\n').forEach((line, index) => {
    const n = index + 1

    for (const match of line.matchAll(/var\((--[\w-]+)/g)) {
      if (!definedVars.has(match[1])) {
        report(file, n, `undefined variable: ${match[1]}`)
      }
    }

    if (line.includes('!important')) {
      report(file, n, 'uses !important (usually is a patch that hides another problem)')
    }

    if (/\.sidebar\.[a-z]/.test(line)) {
      report(file, n, 'suspicious selector: did you want .sidebar.something (two underscores)?')
    }

    if (line.includes(':') && /#(?=[0-9a-zA-Z]*[g-zG-Z])[0-9a-zA-Z]{3,8}\b/.test(line)) {
      report(file, n, `non-hex colors: ${line.trim()}`)
    }

    if (!isIndex) {
      if (/#[0-9a-fA-F]{3,8}\b/.test(line) || /rgba?\(/.test(line)) {
        report(file, n, `handwritten color (should be var(...)): ${line.trim()}`)
      }
    }
  })
}

for (const file of codeFiles) {
  const text = readFileSync(file, 'utf8')

  text.split('\n').forEach((line, index) => {
    const n = index + 1

    if (/sidebar--(nav|icon|link|footer|brand)/.test(line)) {
      report(file, n, 'class with "--" where it should be "__": sidebar__nav, sidebar__link...')
    }

    for (const match of line.matchAll(/[a-z][a-z0-9]*__[a-z0-9-]+(?:--[a-z0-9-]+)?|[a-z][a-z0-9]*--[a-z0-9-]+/g)) {
      const token = match[0]
      if (token.endsWith('-')) continue
      if (!definedClasses.has(token)) {
        report(file, n, `the class "${token}" is used here but not in any CSS`)
      }
    }
  })
}

console.log(`Reviewed: ${cssFiles.length} CSS files and ${codeFiles.length} TSX files.\n`)

if (problems.length === 0) {
  console.log('NO PROBLEMS FOUND')
} else {
  console.log(`${problems.length} detected issue(s): \n`)
  console.log(problems.join('\n'))
  process.exitCode = 1
}
