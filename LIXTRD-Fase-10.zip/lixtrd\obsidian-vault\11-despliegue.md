# 11 - Despliegue y Producción LIXTRD Mark II

## Objetivo

Desplegar la aplicación LIXTRD Mark II en entorno de producción con configuración adecuada, variables de entorno, y garantías de estabilidad para trading en vivo.

## Build de Producción

### Comando Vite

```bash
npm run build
```

Esto genera:
- `dist/` con archivos estáticos optimizados
- `assets/` con CSS/JS hasheados
- `index.html` entry point

### Análisis de Bundle

- **Objetivo**: mantener bundle < 500KB gzip
- **Code splitting**: routes divididas en chunks separados
- **Tree shaking**: eliminación de código muerto TypeScript
- **CSS minification**: PurgeCSS para estilos unused removidos

## Variables de Entorno (.env)

### Archivo `.env.production`

```
NODE_ENV=production
VITE_API_URL=https://api.lixrd.io/v1
VITE_WS_WSURL=wss://api.lixrd.io/ws
VITE_APP_NAME=LIXTRD Mark II
VITE_CONFIDENCE_DEFAULT=0.6
VITE_SHADOW_MODE=false
VITE_ASSETS_DIR=/assets/
```

### Variables Críticas (nunca commitear)

```
VITE_API_URL=https://TU_API_REAL
VITE_WS_WSURL=wss://TU_WS_REAL
```

## Configuración del Servidor

### Nginx (example)

```nginx
server {
    listen 80;
    server_name api.lixrd.io;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }

    location /ws {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }
}
```

### Puerto 3000 (Vite dev server production mode)

```bash
npx vite --config vite.prod.config.js
# or
npm run preview
```

## Docker Despliegue

### Dockerfile

```dockerfile
FROM node:20-alpine AS build

WORKDIR /app
COPY package*.json ./
RUN npm ci --production

COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
COPY --from=build /app/nginx.prod.conf /etc/nginx/conf.d/default.conf

EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

### docker-compose.yml

```yaml
version: '3.8'
services:
  app:
    build: .
    ports:
      - "80:80"
    environment:
      - NODE_ENV=production
      - VITE_API_URL=${API_URL}
      - VITE_WS_WSURL=${WS_URL}
    volumes:
      - ./.env.production:/app/.env.production:ro
```

## Monitoreo y Logging

### Métricas Esenciales

- **WS conexión status**: conectados/desconectados por usuario
- **Señales por minuto**: tasa de generación
- **Errores de API**: count y tipos (rate_limit, network, auth)
- **Latencia WS**: promedio y p95
- **Memory usage**: heap usage del proceso Node
- **Uptime**: tiempo ininterrumpido

### Herramientas

- **Prometheus + Grafana**: métricas tiempo real
- **Winston/Winston Daily**: logs file rotation
- **Sentry**: captura errores frontend y backend
- **Health endpoint**: `/health` con status JSON

## Backup y Recuperación

### Datos Críticos

- `.env.production` (nunca en repo)
- `data/auditoria.db` (SQLite - backup diario)
- Configuración de umbrales (si persistente en archivo JSON)

### Schedule

- **Backup DB**: `0 2 * * * pg_dump ...` o copia SQLite
- **Config backup**: `0 3 * * * cp config/*.json config/backup/`
- **Retention**: 30 días en servidor, 90 días en cloud storage

## Próximos Pasos

- Configurar dominio y SSL (Let's Encrypt)
- Implementar monitoring Prometheus básico
- Probar Docker build y deployment
- Configurar CI/CD con GitHub Actions
- Documentar procedimientos de rollback