# 07 - Gestión de Riesgo y Auditoría LIXTRD Mark II

## Objetivo

Implementar sistema completo de gestión de riesgo y auditoría completa para todas las operaciones y señales en todos los grupos de activos. Cumplimiento de políticas y reporte de métricas de seguridad.

## Política de Riesgo

### Umbrales Configurables

Cada operación y señal lleva límites definidos:

| Parámetro | Valor Por Defecto | Descripción |
|-----------|------------------|-------------|
| **Confianza mínima** | 0.6 | Umbral para aprobar señal en modo real |
| **Exposición máxima** | 25% | % máximo del capital por operación |
| **Drawdown diario** | -5% | Detener trading si se pierde 5% del día |
| **Límite operaciones/hora** | 5 | Máximo de señales por hora por usuario |
| **Modo shadow** | false | Cuando true, sin operaciones reales |

### Validación en Flujo

```mermaid
flowchart TD
    A[Genera Señal] --> B[Validar Confianza ≥ umbral]
    B -->|No| C[Descartar Señal|Registrar]
    B -->|Sí| D[Validar Exposición Máxima]
    D -->|No| E[Reducir Tamaño|Bloquear]
    D -->|Sí| F[Validar Drawdown Diario]
    F -->|No| G[Bloquear Día|Modo Shadow]
    F -->|Sí| H[Aprobar para Ejecución]
    H --> I[Ejecutar o Shadow]
    I --> J[Guardar en SQLite Auditoría]
```

### Modo Shadow (Simulation)

- Todas las señales se generan y registran
- **No se ejecutan órdenes reales**
- Resultados simulados con P/L ficticio
- **Recomendado**: 20 sesiones mínimas en modo shadow antes de modo real
- **Reporte**: Precisión histórica, tasa de acierto, métricas de riesgo

## Estructura de Auditoría (SQLite)

### Tablas Principales

#### `signals`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| id INTEGER PRIMARY KEY | INTEGER | Identificador único |
| symbol TEXT | Texto | Símbolo del activo |
| type TEXT | Texto | crypto/memecoin/future/index/metal |
| side TEXT | Texto | buy/sell |
| price REAL | Real | Precio de señal |
| confidence REAL | Real | 0.0 a 1.0 |
| status TEXT | Texto | pending/accepted/rejected |
| timestamp INTEGER | Entero | epoch ms |
| activo_group TEXT | Texto | grupo al que pertenece |
| metadata TEXT | Texto | JSON con datos adicionales |

#### `decisions`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| id INTEGER PRIMARY KEY | INTEGER | Identificador único |
| signal_id INTEGER | Entero | FK a signals |
| rule_expertas TEXT | Texto | Qué regla disparó |
| estadistica_score REAL | Real | Puntuación estadística |
| anomalia_ia REAL | Real | Score de anomalía IA |
| confianza_final REAL | Real | Valor final combinado |
| aprobado BOOLEAN | Booleano | ¿Fue aprobado? |
| timestamp INTEGER | Entero | epoch ms |

#### `audit_log`

| Campo | Tipo | Descripción |
|-------|------|-------------|
| id INTEGER PRIMARY KEY | INTEGER | Identificador único |
| evento TEXT | Texto | Qué sucedió |
| detalle TEXT | Texto | Descripción JSON |
| actor TEXT | Texto | Usuario/Sistema |
| timestamp INTEGER | Entero | epoch ms |
| tabla_afectada TEXT | Texto | signals/decisions/auditoría |
| registro_id INTEGER | Entero | ID del registro afectado |

### Consultas Útiles

```sql
-- Señales del día con confianza baja
SELECT * FROM signals 
WHERE date(timestamp, 'unixepoch') = date('now')
AND confidence < 0.6;

-- Tasa de acierto por grupo
SELECT activo_group,
       COUNT(CASE WHEN status = 'accepted' THEN 1 END) * 100.0 / COUNT(*) as success_rate
FROM signals 
GROUP BY activo_group;

-- Operaciones del día con drawdown
SELECT COUNT(*) as total, SUM(price * 0.01) as p_l_estimado
FROM signals 
WHERE status = 'accepted'
AND date(timestamp, 'unixepoch') = date('now');
```

## Reporte de Riesgo

### Métricas Diarias (generadas al cierre de sesión)

1. **Total de señales generadas**
2. **Señales aprobadas vs descartadas**
3. **Tasa de acierto** (aprobadas que resultaron ganadoras)
4. **Drawdown diario** (pérdidas netas del día)
5. **Exposición máxima alcanzada** (% capital)
6. **Modo operación** (real/shadow)
7. **Tiempo de conexión WS** (disponibilidad)

### Advertencias Obligatorias (Sempre Mostradas)

Al iniciar la aplicación, el usuario debe ver obligatoriamente:

```
ADVERTENCIA DE RIESGO
=====================
El trading de CFDs, Futuros y Académico conlleva un alto riesgo.
Puedes perder más de tu depósito inicial.

Este software es una herramienta de asistencia para la toma de decisiones.
No garantiza beneficios económicos.

Se recomienda operar en cuenta DEMO durante al menos 20 sesiones
(aprox. 1 mes) antes de usar capital real.

Mantén supervisión humana constante. Los fallos técnicos o datos
desactualizados pueden resultar en señales incorrectes.
```

## Próximos Pasos

- Implementar validaciones en tiempo real en el flujo de señal
- Conectar con dashboard (sesión 06) para mostrar métricas
- Configurar alertas automáticas por umbrales excedidos
- Generar reportes mensuales automatizados
- Integrar con external risk management systems via API