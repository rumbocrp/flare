# 10 - Metales Preciosos LIXTRD Mark II

## Objetivo

Extender la plataforma para rastrear y operar metales preciosos (oro, plata, platino, paladio) en formato spot y futuros, con factores de mercado y relaciones entre metales.

## Metales Soportados

### Oro (XAUUSD)

- Símbolo: XAUUSD, GC (futuros), GOLD (spot)
- Precio: onzas troy en dólares estadounidenses
- Horarios: 24h durante semana (DOM-VIE), cierre viernes 17:00 ET
- Factores: dólar fuerte (inverso), tipos reales, inflación CPI, geopolítica

### Plata (XAGUSD)

- Símbolo: XAGUSD, AG (futuros)
- Relación Oro/Plata: ratio históricamente 50:1 a 80:1
- Volatilidad: mayor que oro, menor que memecoins
- Usos: industria electrónica, joyería, inversión
- Horarios: casi 24h, sigue factores similares al oro

### Platino (XPTUSD) y Paladio (XPDUSD)

- Usos principales: catalizadores automotrices
- Producción: Sudáfrica, Rusia, EE.UU.
- Volatilidad: platino/alto, paladio/muy alta (industria automotriz)

## Factores de Mercado

### Oro

| Factor | Impacto | Descripción |
|--------|---------|-------------|
| Dólar fuerte | Negativo | Cuando USD sube, oro suele bajar |
| Tipos reales positivos | Negativo | Tasas altas reducen atractivo |
| CPI/Inflación | Positivo | Alta inflación impulsa tradicionalmente oro |
| Geopolítica | Variable | Crisis incrementan demanda refugio |
| Reservas banks centrales | Positivo | Compras/vendas mueven precio |

### Plata

| Factor | Impacto | Descripción |
|--------|---------|-------------|
| Correlación oro | Alta (~0.7) | Moverse juntos a menudo |
| Demanda industrial | Positiva | 50-60% de usos industriales |
| Relación oro/plata | Range | Tipico: 50-80, operar el spread |
| Volatilidad | Alta | 2-3x oro en días normales |

### Platino/Paladio

| Factor | Impacto | Descripción |
|--------|---------|-------------|
| Demanda automotriz | Muy alta | 60-80% de uso industrial |
| Regulaciones emissions | Crítico | Cambios de leyes afectan precio inmediatamente |
| Producción geográfica | Crítico | Sudáfrica/Rusia dominio >70% |
| Substituto catalíticos | Negativo | Desarrollo de tecnologías sin Pt/Pd |

## Integración de Datos

 Fuentes principales: Yahoo Finance (XAUUSD, XAGUSD, XPTUSD, XPDUSD), Kitco, Investing.com, LBMA (fixing twice daily).

## Datos Normalizados

```json
{
  "symbol": "XAUUSD",
  "meta": "gold",
  "price": 2050.50,
  "change": +15.25,
  "changePercent": +0.75,
  "timestamp": 1700000000000,
  "metadata": {
    "xau_percent_change_1h": +0.42,
    "xau_percent_change_24h": +0.75,
    "xau_sma_20": 2030.10,
    "xau_sma_50": 2015.50,
    "xau_rsi_14": 62.5,
    "gold_silver_ratio": 72.5
  }
}
```

## Relación Oro/Plata

```
ratio = price_gold / price_silver
```
- Rango histórico: 30:1 a 120:1
- Rango típico: 50:1 a 80:1
- Operar el spread: comprar oro/vender plata cuando ratio alto, inverso cuando bajo
- Alertas: notificar cuando ratio salga de rango 60-80

## Indicadores Técnicos

### Gold-Specific: RSI 14, SMA 20/50/200, MACD, Bollinger Bands, gold/silver ratio

### Silver-Specific: Igual indicadores que oro pero con mayor volatilidad; industrial production correlation; jewelry demand cycles seasonal

### Platinum/Palladium: Automotive production indices; emissions regulations impact; supply disruption risk

## Estrategias de Trading

### 1. Oro: Almacén de Valor

- Tendencia larga: 6-12 meses
- Cobertura inflación: cuando CPI esperado > meta Fed
- Refugio seguro: aumentar posición en crisis geopolíticas
- Timeframe: swing trading (días-semanas) + posición larga term

### 2. Plata: Spread con Oro + Industrial

- Spread trading: comprar oro, vender plata cuando ratio > 80
- Play industrial: comprar plata cuando demanda industrial expected ↑
- Volatility play: opciones sobre plata ETF
- Timeframe: medium term (semanas-meses)

### 3. Metales Industriales (Pt/Pd)

- Cycle automotive: seguir datos producción vehículos
- Regulatory plays: aproximación a fechas nuevas regulaciones
- Supply risk: monitorear huelgas mineras, cierres smelters
- Timeframe: event-driven + trend following

## Gestión de Riesgo por Meta

### Oro

- Exposure max: 20% del capital (activo refugio conservador)
- Stop loss: 5-8% por operación
- Position size: basado en ATR 14 períodos

### Plata

- Exposure max: 15% del capital (mayor volatilidad)
- Stop loss: 8-12% por operación
- Consideración: correlación con oro en portfolio

### Platino/Paladio

- Exposure max: 10% del capital (altísima volatilidad + riesgo industrial)
- Stop loss: 10-15% por operación
- Position size: muy reducido, consideración de options en lugar de spot

## Próximos Pasos

- Implementar conectores Yahoo/Kitco para metales precious
- Agregar calculadora razón oro/plata en dashboard
- Integrar indicadores técnicos específicos por meta
- Configurar umbrales diferenciados por grupo de metales
- Conectar con dashboard y gestión de riesgo (sesiones 06, 07)
- Agregar datos producción minera y stocks mundiales