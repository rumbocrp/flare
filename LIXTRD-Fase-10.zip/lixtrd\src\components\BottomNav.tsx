import { useState } from 'react'
import './BottomNav.css'
import type { PageId } from '../types'
import { navItems } from '../navItems'

type BottomNavProps = {
  activePage: PageId
  onNavigate: (page: PageId) => void
}

const VISIBLE_COUNT = 4

function BottomNav({ activePage, onNavigate }: BottomNavProps) {
  const [moreOpen, setMoreOpen] = useState(false)

  const visibleItems = navItems.slice(0, VISIBLE_COUNT)
  const moreItems = navItems.slice(VISIBLE_COUNT)
  const moreIsActive = moreItems.some((item) => item.id === activePage)

  function go(page: PageId) {
    onNavigate(page)
    setMoreOpen(false)
  }

  return (
    <nav className="bottom-nav" aria-label="Navegación principal">
      {moreOpen && (
        <div className="bottom-nav__popover" role="menu">
          {moreItems.map((item) => (
            <button
              key={item.id}
              type="button"
              role="menuitem"
              className={`bottom-nav__more-item ${
                activePage === item.id ? 'bottom-nav__more-item--active' : ''
              }`}
              onClick={() => go(item.id)}
            >
              <span aria-hidden="true">{item.icon}</span> {item.label}
            </button>
          ))}
        </div>
      )}

      {visibleItems.map((item) => (
        <button
          key={item.id}
          type="button"
          className={`bottom-nav__item ${
            activePage === item.id ? 'bottom-nav__item--active' : ''
          }`}
          aria-current={activePage === item.id ? 'page' : undefined}
          aria-label={item.label}
          onClick={() => go(item.id)}
        >
          <span className="bottom-nav__icon" aria-hidden="true">
            {item.icon}
          </span>
        </button>
      ))}

      {moreItems.length > 0 && (
        <button
          type="button"
          className={`bottom-nav__item ${
            moreIsActive || moreOpen ? 'bottom-nav__item--active' : ''
          }`}
          aria-label="Más opciones"
          aria-expanded={moreOpen}
          aria-haspopup="menu"
          onClick={() => setMoreOpen((open) => !open)}
        >
          <span className="bottom-nav__icon" aria-hidden="true">
            ⋮
          </span>
        </button>
      )}
    </nav>
  )
}

export default BottomNav
