# LIXTRD · Fase 10 — Indicadores y señales: la estrategia como código

> Este documento es **independiente**: no edita ni reemplaza a los anteriores. Sigue el mismo formato que los de las Fases 4 a 9.

**Antes de empezar necesitas:**

1. Haber terminado la **Fase 9** (gráfico de velas y capa de datos).
2. Tener el proyecto **arrancando y sin errores de TypeScript**: `pnpm dev` y `pnpm exec tsc --noEmit -p tsconfig.app.json`.
3. Trabajar con **pnpm**, no con npm: el proyecto tiene `pnpm-lock.yaml`.
4. Elegir una **fuente de datos**: sintética (recomendada para esta fase) o Binance (datos reales). Los números esperados de la sección 5 solo valen con la sintética.

**Tiempo estimado:** 2–4 horas si escribes y entiendes cada bloque; 45–60 minutos si copias el código y lees las explicaciones.

**Una nota:** no me has dicho todavía tu mercado, tu broker ni tu camino (broker con API o MetaTrader 5). Esta fase **no depende de eso**: los indicadores y las señales funcionan igual para cualquier mercado. La Fase 11 (backtest) sí se beneficiará de saberlo.

**Ruta rápida (para quien ya conoce el proyecto):**

```
0. Verifica la Fase 9 (sección 0)
1. types.ts → 2. index.css → 3. indicators.ts → 4. signals.ts
5. chartLayout.ts → 6. CandleChart.css → 7. CandleChart.tsx
8. RsiPanel.tsx → 9. SignalsTable.tsx → 10. MarketAnalysis.tsx
11. MarketSection.tsx → 12. pruebas (opcional)
13. pnpm dev → sección 5
```

**Cómo está organizado este documento:**

0. Antes de empezar: verificación de la Fase 9
1. Qué haremos
2. Qué cambia y por qué
3. Decisiones que tomé, y qué otras opciones había
4. Pasos para escribir el código
5. Cómo probarlo
6. Si algo falla
7. Alternativas de funcionalidad y de estética
8. Qué puedes cambiar libremente y qué no
9. Retos opcionales
10. Lo que viene
- Anexo A: el script `check-css.mjs`
- Anexo B: valores verificados
- Anexo C: checklist final

**Tres avisos que te ahorrarán tiempo:**

- **`check-css.mjs` está roto en este proyecto.** Reporta cientos de falsos positivos y escribe `&{line}` en lugar del número de línea. **No lo uses como criterio de aprobación**; usa `pnpm build` y revisión visual. Al final hay un anexo con el diagnóstico y un parche opcional.
- **Los datos de ejemplo no son una recomendación.** El cruce de medias es una estrategia educativa. Que genere señales no dice nada sobre su rentabilidad.
- **Los números de la sección 5 dependen de la fuente sintética.** Si usas Binance, la pantalla funciona igual, pero las fechas, los precios y el número de señales serán otros.

---

## 0. Antes de empezar — verificación de la Fase 9

Esta fase se apoya en el gráfico de velas de la Fase 9. Antes de añadir indicadores, comprueba que la base está sana. Si algo falla aquí, arréglalo primero: depurar dos capas a la vez es mucho más difícil.

### 0.1 Checklist de la Fase 9

| # | Qué comprobar | Cómo | Resultado esperado |
|---|---|---|---|
| 1 | Dependencias | `pnpm install` | Termina sin errores. |
| 2 | TypeScript | `pnpm exec tsc --noEmit -p tsconfig.app.json` | No imprime nada (código 0). |
| 3 | Build | `pnpm build` | Genera `dist/` sin errores. |
| 4 | Servidor | `pnpm dev` | Vite muestra una URL local. |
| 5 | Sección | Abre **Estadísticas** y baja a **Precio del mercado**. | La sección existe. |
| 6 | Carga | Cambia de par o de temporalidad. | Aparece un estado de carga y luego el gráfico. |
| 7 | Error | Con `binanceSource`, desconecta la red (o bloquea Binance) y cambia de temporalidad. | Mensaje de error y botón de reintento, no una pantalla en blanco. |
| 8 | Velas | Con la fuente sintética, BTC/USDT 1 h. | 100 velas verdes/rojas; la primera es Dec 27, 20:00 y la última Dec 31, 23:00 (UTC). |
| 9 | Lectura | Pasa el mouse por el gráfico. | Precio, cambio, O/H/L/C y hora UTC cambian juntos. |
| 10 | Temas | Cambia entre oscuro y claro. | Velas, ejes, textos y bordes se leen en los dos. |
| 11 | Persistencia | Recarga la página. | El tema se mantiene; el par y la temporalidad vuelven a sus valores por defecto (es lo esperado en la Fase 9). |

> **Nota sobre los textos:** la `MarketSection` actual tiene varios textos en inglés ("Market Price", "Loading candles...", "Retry"). El paso 11 los reemplaza por español. No es un error de la Fase 9; es deuda de traducción que esta fase salda.

### 0.2 Comandos de verificación

Desde la raíz del proyecto (`lixtrd/`):

```powershell
pnpm install
pnpm exec tsc --noEmit -p tsconfig.app.json
pnpm build
pnpm dev
```

- `pnpm exec` ejecuta una herramienta instalada en el proyecto. `pnpm dlx` descargaría una temporal; no lo necesitas aquí.
- `pnpm build` ejecuta `tsc -b && vite build`. Es la comprobación más completa antes de abrir el navegador.
- Si `pnpm` avisa de **build scripts ignorados** (por ejemplo, `esbuild`), ejecuta `pnpm approve-builds`, elige `esbuild` y vuelve a intentar. Es una protección de pnpm, no un error del proyecto.
- Si `pnpm dev` abre en otro puerto, usa el que indique la terminal.

### 0.3 Elige la fuente de datos (importante para los números)

El proyecto trae dos fuentes:

| Fuente | Archivo | Cuándo usarla |
|---|---|---|
| **Sintética** | `src/market/synthetic.ts` | Para esta fase: datos deterministas, sin red y con números reproducibles. |
| **Binance** | `src/market/binance.ts` | Para ver precios reales (Fase 12 en adelante). |

Ahora mismo `src/market/index.ts` apunta a Binance:

```ts
import { binanceSource } from './binance'
import type { MarketDataSource } from '../types'

export const marketDataSource: MarketDataSource = binanceSource
```

**Para esta fase, cámbialo a la fuente sintética:**

```ts
import { syntheticSource } from './synthetic'
import type { MarketDataSource } from '../types'

export const marketDataSource: MarketDataSource = syntheticSource
```

Así los ejemplos de la sección 5 coinciden **siempre**: la fuente sintética usa una semilla fija por par y temporalidad, no consulta la red y no cambia entre recargas. Cuando termines la fase, puedes volver a Binance cambiando el import y la constante.

**Qué genera la fuente sintética (BTC/USDT, 1 h, 100 velas):**

- Primera vela: **Dec 27, 2025, 20:00 UTC**.
- Última vela: **Dec 31, 2025, 23:00 UTC**.
- Último cierre: **62,674.74**.
- El generador termina en `Date.UTC(2026, 0, 1)`; por eso los datos son de finales de 2025 aunque hoy estemos en 2026. Es intencional: así los ejemplos son estables.

> **Si ves otras fechas o precios**, estás usando Binance (o cambiaste `synthetic.ts`). No es un error, pero la tabla de la sección 5 no coincidirá.

### 0.4 Arreglos mínimos recomendados (5 minutos)

Estos detalles vienen de la Fase 9 y afectan a la Fase 10. Son **opcionales**, pero si los dejas como están, tendrás que ajustar algunas expectativas.

**1. `sideLabels` en `src/trades.ts`.** Hoy la tabla de operaciones muestra `BUY`/`SELL`; la tabla de señales de esta fase está pensada en español. Cambia:

```ts
export const sideLabels: Record<TradeSide, string> = {
  buy: 'Compra',
  sell: 'Venta',
}
```

Efecto: **las dos tablas** (operaciones y señales) mostrarán `Compra`/`Venta`. Si prefieres mantener `BUY`/`SELL`, cambia también la tabla esperada de la sección 5; no mezcles los dos idiomas en la misma pantalla.

**2. El cambio negativo no se pinta de rojo.** En `src/components/EquityChart.css` hay un selector con un nombre que no existe:

```css
.color__change--negative {   /* mal */
  color: var(--negative);
}
```

`CandleChart.tsx` usa `chart__change--negative`. Corrige el selector:

```css
.chart__change--negative {
  color: var(--negative);
}
```

**3. El texto vacío es invisible.** En el mismo archivo:

```css
.chart__empty {
  ...
  color: var(--surface);   /* igual que el fondo */
}
```

Cámbialo por un color legible:

```css
.chart__empty {
  ...
  color: var(--text-muted);
}
```

Sin esto, "No hay velas para mostrar." y "No hay datos suficientes para el RSI." se ven del color del fondo.

**4. Traduce la metadata de la fuente (opcional).** Si quieres que el pie de la sección sea todo español:

- En `synthetic.ts`: `name: 'Datos sintéticos'`, `description: 'Velas generadas localmente. No son datos reales.'`
- En `binance.ts`: `name: 'API pública de Binance'`, `description: 'Precios reales del mercado.'`

**5. Mueve la sección (opcional).** En `src/pages/Stats.tsx`, `<MarketSection />` está al final, después de la tabla de operaciones. Si quieres verla antes, muévela justo después de la sección "Indicadores de riesgo". No es necesario para esta fase.

**6. No uses `check-css.mjs` como semáforo.** Está roto: sus 249 avisos son falsos positivos y el número de línea sale como `&{line}`. El anexo A explica por qué y cómo parchearlo. Mientras tanto, usa `pnpm build` y revisa los dos temas a ojo.

### 0.5 Problemas conocidos de la Fase 9

| Detalle | Estado actual | Qué hacer |
|---|---|---|
| Fuente de datos | `binanceSource` | Cambiar a `syntheticSource` para la sección 5 (0.3). |
| Textos de `MarketSection` | En inglés | Se reemplazan en el paso 11. |
| `Interval` incluye `5m` | Sí | Se conserva; el paso 11 añade la opción "5 min". |
| `sideLabels` | `BUY`/`SELL` | Cambiar a `Compra`/`Venta` (0.4.1). |
| `check-css.mjs` | Roto | Ignorar; anexo A. |
| `.chart__empty` | Invisible | Corregir el color (0.4.3). |
| `.chart__change--negative` | Selector mal escrito | Corregir (0.4.2). |
| Lectura O/H/L/C + UTC | Ya funciona | No tocar. |
| Estado de carga | Ya existe | Se traduce en el paso 11. |

### 0.6 Criterio de salida

No empieces el paso 1 hasta que puedas marcar esto:

- [ ] `pnpm exec tsc --noEmit -p tsconfig.app.json` termina sin errores.
- [ ] `pnpm build` termina sin errores.
- [ ] `pnpm dev` abre la app.
- [ ] Con la fuente sintética, BTC/USDT 1 h muestra 100 velas y el eje del gráfico va de `Dec 27, 20:00` a `Dec 31, 23:00 UTC`.
- [ ] El hover cambia precio, O/H/L/C y hora.
- [ ] Los dos temas se leen bien.
- [ ] Decidiste qué fuente de datos usarás y lo anotaste.

---

## 1. Qué haremos

Hasta la Fase 9, la app **muestra** velas. En esta fase empieza a **pensar** sobre ellas: calcula indicadores, decide cuándo "hay una señal" y la dibuja.

Lo que tendremos al final, en la sección "Precio del mercado" de Estadísticas:

- **Dos medias móviles dibujadas sobre las velas** (una rápida y una lenta), en la versión **SMA** (simple) o **EMA** (exponencial), a elección.
- **Marcadores ▲ y ▼** sobre las velas donde la media rápida cruza a la lenta (la señal de la estrategia).
- Un **panel de RSI** debajo del gráfico, alineado con las velas, con las zonas de 30 y 70.
- Una **tabla de señales** con la vela, el lado, el precio de referencia y el motivo.
- Tres controles para la estrategia: **media rápida**, **media lenta** y **tipo de media**. Se recuerdan al recargar (con el hook de la Fase 8).
- Un conjunto de **pruebas automáticas** (opcional) que verifican las fórmulas.

Un boceto de cómo se verá:

```
Precio del mercado         [ BTC/USDT | ETH/USDT | SOL/USDT ]  [ 5 min | 15 min | 1 h | 4 h | 1 día ]

 Media rápida [ 9 velas v ]   Media lenta [ 20 velas v ]   Tipo de media [ SMA | EMA ]

 62,674.74  -0.42%   O 62,936.44 · H 62,987.70 · L 62,521.97 · C 62,674.74   Dec 31, 23:00 UTC
 ── SMA 9   ── SMA 20   ▲ Compra   ▼ Venta

 63,000 ┤
 62,000 ┤      ▼
 61,000 ┤   ┃  ┃  ╲___                    ← la media rápida (naranja) cruza
 60,000 ┤  ┃ ┃    ┃  ╲╲___    ▲              a la lenta (celeste)
 59,000 ┤                  ╲╲___┃___╱
        Dec 27, 20:00                          Dec 31, 23:00

 RSI 14: 54.2
 70 ┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄  (zona alta)
 30 ┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄  (zona baja)

Señales (2)
 Vela (UTC)       Lado    Precio de referencia   Motivo
 Dec 29, 17:00    Venta        60,862.24         SMA 9 cruza por debajo de SMA 20
 Dec 30, 09:00    Compra       61,032.03         SMA 9 cruza por encima de SMA 20
```

> **Esto es un ejemplo educativo, no una estrategia recomendada.** El cruce de medias es de las estrategias más simples que existen, y se usa precisamente porque es fácil de entender y de probar. **Que genere señales no dice nada sobre si es rentable.** Eso lo medirá el backtest de la Fase 11, y aun así, con cautela.

### Cómo funcionan los indicadores y las señales, en 8 ideas

**1. Un indicador es una función de la historia.** Recibe una lista de precios de cierre y devuelve **otra lista del mismo largo**: un valor por vela. Por ejemplo, la media de las últimas 20 velas, calculada para cada vela.

**2. El calentamiento (*warm-up*).** Para calcular una media de 20 velas hacen falta 20 velas. Las primeras 19 **no tienen valor**. Esos huecos se representan con `null` (nada), **no con 0**: un 0 sería un dato falso que dibujaría una línea que cae al suelo. Por eso las funciones devuelven `(number | null)[]`.

**3. SMA y EMA.** La **SMA** (media simple) da el mismo peso a las últimas N velas. La **EMA** (media exponencial) da **más peso a las más recientes**, así que reacciona antes. Misma idea, distinta sensibilidad.

**4. El RSI mide la fuerza de las subidas frente a las bajadas.** Va de 0 a 100. Compara cuánto subió el precio de media, y cuánto bajó, en las últimas N velas. Por convención, **por encima de 70** se considera zona "alta" y **por debajo de 30**, "baja". **No es una señal por sí solo**: en una tendencia fuerte puede quedarse en zona alta mucho tiempo. Se puede comprobar a mano (ver sección 4, paso 3).

**5. Una señal es un evento, no una orden.** Aquí, la señal ocurre en la vela donde la media rápida **cruza** a la lenta. Tres palabras que se confunden y no son lo mismo:

| Palabra | Qué es |
|---|---|
| **Señal** | "La condición se cumplió en esta vela." Es información. |
| **Orden** | "Quiero comprar o vender." Es una petición. |
| **Operación** | "Ya compré y ya vendí." Un ciclo completo, con resultado. |

La señal **se confirma al cierre de la vela**. En el backtest (Fase 11), la orden se ejecutará en la **apertura de la siguiente vela**, no en el mismo precio de cierre.

**6. Sin mirar al futuro.** El valor del indicador en la vela *i* solo usa velas **hasta la *i***, y la señal en la vela *i* solo compara la vela *i* con la *i − 1*. Si una estrategia usara la vela *i + 1* para decidir en la *i*, el backtest saldría "perfecto" y sería **mentira**. Es el error más común y más caro del trading automático. Más adelante hay una prueba que lo verifica.

**7. El repintado.** Con datos en vivo, la última vela **aún no cerró** y su precio sigue cambiando. Una señal que "aparece" sobre ella puede **desaparecer** segundos después. Por eso, en la fase de shadow, solo se actuará sobre velas **cerradas**. Con los datos de ahora (todas cerradas) no pasa, pero conviene saberlo desde ya.

**8. Funciones puras.** Todas las funciones de esta fase **reciben datos y devuelven datos**, sin leer el navegador, sin guardar nada, sin depender de la hora. Con los mismos datos, siempre dan el mismo resultado. Eso las hace **fáciles de probar** y **reutilizables**: el motor de backtest de la Fase 11 usará exactamente la misma función que hoy dibuja los triángulos.

---

## 2. Qué cambia y por qué

| Archivo | Qué pasa | Por qué |
|---|---|---|
| `src/trades.ts` | **Pre-flight (recomendado):** `sideLabels` pasa a `Compra`/`Venta`. | Para que la tabla de señales y la de operaciones usen el mismo idioma. |
| `src/market/index.ts` | **Pre-flight (recomendado):** usar `syntheticSource`. | Números reproducibles en la sección 5. |
| `src/components/EquityChart.css` | **Pre-flight (recomendado):** corrige `.chart__change--negative` y el color de `.chart__empty`. | Para que los cambios negativos y los mensajes vacíos se vean. |
| `src/types.ts` | **Modificado:** se añaden `AverageKind`, `SignalParams`, `Signal`, `OverlayKind` y `ChartOverlay` al final. Se conserva `5m` en `Interval`. | Describen los parámetros de la estrategia, una señal y una línea dibujada sobre el gráfico. |
| `src/index.css` | **Modificado:** 4 variables de color nuevas **en los dos temas**. | Los colores de las medias y de los marcadores, definidos una sola vez. |
| `src/indicators.ts` | **Nuevo:** `sma`, `ema` y `rsi`. | Las matemáticas, aparte de las pantallas y fáciles de probar. |
| `src/signals.ts` | **Nuevo:** parámetros por defecto, opciones, validación y la función `crossoverSignals`. | La estrategia como una función pura. |
| `src/chartLayout.ts` | **Nuevo:** los márgenes laterales compartidos. | Para que las velas y el panel de RSI queden **alineados verticalmente**. |
| `src/components/CandleChart.css` | **Modificado:** estilos de las líneas, los marcadores, la leyenda, el RSI y los controles. | Específicos de estos gráficos. |
| `src/components/CandleChart.tsx` | **Reemplazado:** acepta líneas (`overlays`) y señales (`signals`) opcionales. | Dibuja medias y marcadores **sin romper** el uso que ya tiene. |
| `src/components/RsiPanel.tsx` | **Nuevo:** el panel de RSI. | Un indicador con escala propia (0 a 100) no puede ir sobre el eje de precios. |
| `src/components/SignalsTable.tsx` | **Nuevo:** la tabla de señales. | Reutiliza los estilos de la tabla de operaciones. |
| `src/components/MarketAnalysis.tsx` | **Nuevo:** calcula los indicadores y reúne gráfico, RSI y tabla. | Mantiene `MarketSection` enfocado en controles y estados. |
| `src/components/MarketSection.tsx` | **Reemplazado:** añade los tres controles de la estrategia, traduce los textos y usa `MarketAnalysis`. | Aquí vive el estado de los parámetros. |
| `src/indicators.test.ts` y `package.json` | **Nuevos/modificados (opcional):** pruebas automáticas con Vitest y comando `pnpm test`. | Para verificar las fórmulas y que no se mire al futuro. |
| `Stats.tsx`, `App.tsx`, `App.css` y el resto | **Sin cambios.** | `MarketSection` ya estaba colocada en Estadísticas. |

### Lo nuevo de esta fase: lógica que se puede "probar sin abrir el navegador"

Hasta ahora, la única forma de saber si algo funcionaba era **mirar la pantalla**. Las funciones puras de esta fase se pueden verificar con **entradas y salidas conocidas**: *"la media de [1, 2, 3] con periodo 3 es 2"*. Ese hábito (escribir lo que esperas y dejar que una máquina lo compruebe) es la base de todo lo que viene. Un motor de backtest sin pruebas es una calculadora que nadie ha comprobado.

---

## 3. Decisiones que tomé, y qué otras opciones había

| Decisión | Lo que elegí | Por qué | Otras opciones |
|---|---|---|---|
| **Qué estrategia** | **Cruce de dos medias.** | Es la más simple de entender y de probar, y sirve para estrenar todo el circuito (indicador → señal → gráfico → backtest). | Ruptura de máximos (Donchian), reversión con RSI, combinación de varias. Todas cumplen la misma forma: *velas y parámetros entran, señales salen*. |
| **Dónde viven los parámetros** | En un **tipo propio**, `SignalParams`, guardado aparte (`lixtrd:signal-params`). | La estrategia de riesgo (`Strategy`: tamaño, stop loss...) y la lógica de señales son **dos cosas distintas**. Mezclarlas obligaría a tocar el formulario de Ajustar bot y lo ya guardado por la gente. | Añadirlos a `Strategy` (más cohesivo, pero toca varios archivos y rompe lo guardado). En la Fase 11 las dos se combinarán de forma ordenada. |
| **Cómo se eligen los periodos** | **Selectores con opciones fijas** (rápida: 5, 9, 12; lenta: 20, 26, 50). | Con opciones fijas, **no hay combinaciones inválidas**: la rápida siempre es menor que la lenta. Sin validar nada. | Campos numéricos libres (más flexible, pero hay que validar que la rápida sea menor que la lenta; ver reto 1). |
| **Cómo se calculan los indicadores** | **Funciones puras** en `indicators.ts`. Se recalculan en cada dibujo. | Con 100 velas es instantáneo. Y no hay estado que se pueda desincronizar. | `useMemo` (útil con miles de velas); una librería de indicadores ya hecha (ahorra escribir, pero tienes que **comprobar** que sus fórmulas son las que crees). |
| **Qué devuelve un indicador** | Una lista del **mismo largo** que las velas, con `null` durante el calentamiento. | Todo queda alineado por posición: el valor `i` es de la vela `i`. | Una lista más corta (más compacta, pero hay que llevar la cuenta del desfase en cada uso). |
| **La semilla de la EMA** | La **SMA** de las primeras N velas. | Es la convención más extendida. | Empezar desde el primer precio (da valores desde la primera vela, pero con mucho ruido al inicio). |
| **El suavizado del RSI** | El de **Wilder** (el original del RSI). | Es la definición estándar. | Usar una media simple (da valores algo distintos). |
| **Cuándo hay cruce** | `anterior_rápida <= anterior_lenta` **y** `actual_rápida > actual_lenta`. | El `<=` evita perder un cruce que empieza tocándose, y el `>` estricto evita señales repetidas mientras están iguales. | Usar solo `<` y `>` (puede perder cruces que empiezan en igualdad). |
| **Precio de referencia de la señal** | El **cierre** de la vela de la señal. | Es el precio que se conoce cuando la señal se confirma. | La apertura de la siguiente vela (lo que usará el backtest). Aquí es solo informativo. |
| **Dónde se dibuja el RSI** | En un **panel aparte**, debajo, alineado con las velas. | Su escala (0 a 100) no tiene nada que ver con la del precio. | Una línea sobre las velas (confuso), o no dibujarlo. |
| **Cómo se alinean** | Los dos gráficos comparten los **márgenes laterales** (`chartLayout.ts`). | La vela de las 14:00 queda justo encima del valor del RSI de las 14:00. | Alinearlos "a ojo" (se desalinean al cambiar un margen). |
| **Colores** | **Variables nuevas** (`--overlay-fast`...), definidas en los dos temas. | Cambian con el tema, como todo lo demás. | Reutilizar variables existentes (menos archivos, pero se confundiría con el verde/rojo de las velas). |
| **Los marcadores** | Triángulos: ▲ debajo de la vela (compra), ▼ encima (venta). | La **forma** distingue compra de venta aunque no distingas bien los colores. | Letras ("C"/"V") o líneas verticales. |
| **Pruebas** | **Vitest**, opcional. | Se integra con Vite y no exige configuración. | Jest; o un script propio con datos conocidos. |

---

## 4. Pasos para escribir el código

Escribe los archivos **en este orden**:

1. `src/types.ts` (añadir tipos)
2. `src/index.css` (4 variables en cada tema)
3. `src/indicators.ts` (nuevo)
4. `src/signals.ts` (nuevo)
5. `src/chartLayout.ts` (nuevo)
6. `src/components/CandleChart.css` (añadir al final)
7. `src/components/CandleChart.tsx` (reemplazar)
8. `src/components/RsiPanel.tsx` (nuevo)
9. `src/components/SignalsTable.tsx` (nuevo)
10. `src/components/MarketAnalysis.tsx` (nuevo)
11. `src/components/MarketSection.tsx` (reemplazar)
12. Pruebas con Vitest (opcional)

> **Hasta el paso 10 la pantalla no cambia**, y ningún paso deja rojo en otro archivo, porque `CandleChart` recibe sus datos nuevos como **opcionales** y `Interval` conserva `5m`. Cuando termines el paso 11, aparece todo junto. Después del paso 6 y al terminar, ejecuta `pnpm build` y revisa los dos temas; **no uses `check-css.mjs` como semáforo** (está roto, ver anexo A).

---

### Paso 1 — `src/types.ts` (añade los tipos nuevos al final)

Añade estos tipos **al final** de `src/types.ts`. El archivo completo (con los tipos nuevos) queda así:

```ts
export type PageId =
  | 'dashboard'
  | 'bot-config'
  | 'bot-run'
  | 'stats'
  | 'settings'

export type BotStatus = 'stopped' | 'running'

export type Strategy = {
  pair: string
  positionSize: number
  stopLoss: number
  takeProfit: number
  maxDailyRisk: number
}

export type TradeSide = 'buy' | 'sell'

export type Trade = {
  id: number
  time: string
  pair: string
  side: TradeSide
  entryPrice: number
  exitPrice: number
  size: number
}

export type Tone = 'positive' | 'negative' | 'neutral'

export type ChartPoint = {
  label: string
  value: number
}

export type ThemeSetting = 'dark' | 'light' | 'system'

export type AppSettings = {
  theme: ThemeSetting
}

export type Candle = {
  time: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

export type Interval = '5m' | '15m' | '1h' | '4h' | '1d'

export type CandleRequest = {
  pair: string
  interval: Interval
  limit: number
  signal?: AbortSignal
}

export type MarketDataSource = {
  name: string
  description: string
  getCandles: (request: CandleRequest) => Promise<Candle[]>
}

export type AsyncState<T> =
  | { status: 'loading' }
  | { status: 'error'; message: string }
  | { status: 'success'; data: T }

export type AverageKind = 'sma' | 'ema'

export type SignalParams = {
  fastPeriod: number
  slowPeriod: number
  average: AverageKind
}

export type Signal = {
  index: number
  time: number
  side: TradeSide
  price: number
  reason: string
}

export type OverlayKind = 'fast' | 'slow'

export type ChartOverlay = {
  id: string
  label: string
  kind: OverlayKind
  values: (number | null)[]
}
```

> **`Interval` conserva `5m`.** La Fase 9 ya lo tenía y el paso 11 lo mantiene en la interfaz. Si lo borras aquí, el `MarketSection` actual no compilará hasta que termines el paso 11. No hay ninguna prisa por eliminarlo.

**Qué hace cada tipo nuevo:**

- **`AverageKind`**: `'sma'` o `'ema'`.
- **`SignalParams`**: los tres parámetros de la estrategia: periodo de la media rápida, periodo de la lenta y el tipo de media.
- **`Signal`**: un evento de la estrategia.
  - `index`: el **número de la vela** en la lista (0 es la primera).
  - `time`: el inicio de esa vela, en milisegundos (UTC).
  - `side`: `'buy'` o `'sell'`. Reutiliza `TradeSide` de la Fase 5.
  - `price`: el cierre de esa vela, como referencia.
  - `reason`: el motivo, en texto, para mostrarlo.
- **`ChartOverlay`**: una línea que se dibuja **sobre** las velas. `values` tiene un valor por vela (o `null` durante el calentamiento). `kind` decide el color (`'fast'` o `'slow'`).

---

### Paso 2 — `src/index.css` (añade 4 variables en cada tema)

No hay que reemplazar el archivo: solo **añadir líneas**.

**En el bloque `:root { ... }` (tema oscuro)**, antes de la llave de cierre, añade:

```css
  --overlay-fast: #ffb454;
  --overlay-slow: #5ec8ff;
  --signal-buy: #ffffff;
  --signal-sell: #ff4fa3;
```

**En el bloque `:root[data-theme='light'] { ... }`**, antes de su llave de cierre, añade:

```css
  --overlay-fast: #b25e00;
  --overlay-slow: #0b6fa8;
  --signal-buy: #003d00;
  --signal-sell: #b3126b;
```

**Qué son:**

| Variable | Para qué sirve |
|---|---|
| `--overlay-fast` | Color de la media rápida (naranja). |
| `--overlay-slow` | Color de la media lenta (celeste). |
| `--signal-buy` | Color del marcador ▲ de compra. |
| `--signal-sell` | Color del marcador ▼ de venta. |

**Por qué colores distintos al verde y rojo de las velas:** si las medias o los marcadores fueran verdes o rojos, se confundirían con las velas. Los contrastes de estos colores sobre su fondo son de entre 4.45:1 y 21:1 en los dos temas (para gráficos se pide como mínimo 3:1).

**Recuerda:** una variable nueva **debe estar en los dos bloques**. Si falta en el claro, ese elemento se verá con el color oscuro. **No confíes en `check-css.mjs`** para detectarlo: está roto (anexo A). Revisa los dos bloques a mano o busca la variable con `Select-String`.

---

### Paso 3 — `src/indicators.ts` (archivo nuevo)

```ts
export type Series = (number | null)[]

export function sma(values: number[], period: number): Series {
  const result: Series = new Array(values.length).fill(null)
  if (period < 1) return result

  let sum = 0
  for (let index = 0; index < values.length; index++) {
    sum += values[index]
    if (index >= period) sum -= values[index - period]
    if (index >= period - 1) result[index] = sum / period
  }

  return result
}

export function ema(values: number[], period: number): Series {
  const result: Series = new Array(values.length).fill(null)
  if (period < 1 || values.length < period) return result

  const k = 2 / (period + 1)
  let previous =
    values.slice(0, period).reduce((total, value) => total + value, 0) / period
  result[period - 1] = previous

  for (let index = period; index < values.length; index++) {
    previous = values[index] * k + previous * (1 - k)
    result[index] = previous
  }

  return result
}

function toRsi(averageGain: number, averageLoss: number): number {
  if (averageLoss === 0) return averageGain === 0 ? 50 : 100
  return 100 - 100 / (1 + averageGain / averageLoss)
}

export function rsi(values: number[], period = 14): Series {
  const result: Series = new Array(values.length).fill(null)
  if (period < 1 || values.length <= period) return result

  let gainSum = 0
  let lossSum = 0
  for (let index = 1; index <= period; index++) {
    const change = values[index] - values[index - 1]
    if (change >= 0) gainSum += change
    else lossSum -= change
  }

  let averageGain = gainSum / period
  let averageLoss = lossSum / period
  result[period] = toRsi(averageGain, averageLoss)

  for (let index = period + 1; index < values.length; index++) {
    const change = values[index] - values[index - 1]
    const gain = change > 0 ? change : 0
    const loss = change < 0 ? -change : 0

    averageGain = (averageGain * (period - 1) + gain) / period
    averageLoss = (averageLoss * (period - 1) + loss) / period
    result[index] = toRsi(averageGain, averageLoss)
  }

  return result
}
```

**Qué hace:** tres funciones que reciben una lista de precios y devuelven una lista del **mismo largo**. Ninguna usa React ni lee nada de fuera: son pura matemática.

**`Series`**: es un nombre corto para `(number | null)[]`: "una lista donde cada elemento es un número o nada".

**`sma` — media simple, paso a paso:**

- `new Array(values.length).fill(null)` crea una lista del mismo largo, **llena de `null`**.
- La idea eficiente: en vez de volver a sumar 20 números en cada vela, se mantiene una **suma corriente**. Al avanzar una vela, **entra** el precio nuevo (`sum += values[index]`) y **sale** el más viejo (`sum -= values[index - period]`).
- `if (index >= period - 1) result[index] = sum / period`: solo desde que hay `period` velas se escribe el valor. Antes, queda `null` (el calentamiento).
- Con `[1, 2, 3, 4, 5]` y periodo 3 da `[null, null, 2, 3, 4]`: en el índice 2, `(1+2+3)/3 = 2`; en el 3, `(2+3+4)/3 = 3`; en el 4, `(3+4+5)/3 = 4`.
- `if (period < 1) return result` es una protección: un periodo 0 o negativo no tiene sentido.

**`ema` — media exponencial:**

- `k = 2 / (period + 1)` es el **peso** que se le da al precio nuevo. Con periodo 3, `k = 0.5`: la mitad del valor nuevo es el precio actual y la otra mitad es la media anterior. Con periodo 20, `k ≈ 0.095`: el precio nuevo pesa menos, así que la media es más lenta.
- La **semilla**: el primer valor es la SMA de las primeras `period` velas (`values.slice(0, period)` toma esas velas y `reduce` las suma).
- Después, cada valor se calcula con la fórmula `precio × k + anterior × (1 − k)`.
- Con `[2, 4, 6, 8, 6]` y periodo 3: semilla `(2+4+6)/3 = 4`; luego `8×0.5 + 4×0.5 = 6`; luego `6×0.5 + 6×0.5 = 6`. Resultado: `[null, null, 4, 6, 6]`.

**`rsi` — índice de fuerza relativa:**

1. Para cada vela se mira el **cambio** respecto de la anterior: si subió, es una **ganancia**; si bajó, una **pérdida**.
2. Las primeras `period` diferencias se promedian (suma de ganancias ÷ período, y suma de pérdidas ÷ período). Es la base.
3. Desde ahí, el promedio se va **suavizando** (suavizado de Wilder): `nuevo = (anterior × (period − 1) + valor actual) / period`. Es el estándar del RSI.
4. `toRsi` convierte los dos promedios al número final: `RSI = 100 − 100 / (1 + ganancia media / pérdida media)`.
5. **Casos límite:** si no hubo pérdidas, el RSI es 100 (todo subidas); si no hubo ni ganancias ni pérdidas (precio plano), vale 50, por convención. Sin esa protección se dividiría entre cero.
- El primer valor del RSI está en el índice `period` (no en `period − 1`), porque hacen falta `period` **cambios**, y para tener 14 cambios se necesitan 15 velas.

**Cómo comprobar el RSI a mano.** Usa estos 15 cierres: `44.34, 44.09, 44.15, 43.61, 44.33, 44.83, 45.10, 45.42, 45.84, 46.08, 45.89, 46.03, 45.61, 46.28, 46.28`.

- Las ganancias de los 14 cambios suman **3.34** (0.06 + 0.72 + 0.50 + 0.27 + 0.32 + 0.42 + 0.24 + 0.14 + 0.67).
- Las pérdidas suman **1.40** (0.25 + 0.54 + 0.19 + 0.42).
- `RS = 3.34 / 1.40 = 2.3857`, así que `RSI = 100 − 100 / (1 + 2.3857) = 70.46`.

Eso es exactamente lo que devuelve `rsi(...)[14]`. Haz la cuenta tú una vez: es la mejor forma de entender qué mide.

---

### Paso 4 — `src/signals.ts` (archivo nuevo)

```ts
import { ema, sma } from './indicators'
import type { AverageKind, Candle, Signal, SignalParams } from './types'

export const RSI_PERIOD = 14

export const fastOptions = [5, 9, 12]
export const slowOptions = [20, 26, 50]

export const averageOptions: { id: AverageKind; label: string }[] = [
  { id: 'sma', label: 'SMA' },
  { id: 'ema', label: 'EMA' },
]

export const defaultSignalParams: SignalParams = {
  fastPeriod: 9,
  slowPeriod: 20,
  average: 'sma',
}

export function isSignalParams(value: unknown): value is SignalParams {
  if (typeof value !== 'object' || value === null) return false

  const candidate = value as Record<string, unknown>

  return (
    typeof candidate.fastPeriod === 'number' &&
    fastOptions.includes(candidate.fastPeriod) &&
    typeof candidate.slowPeriod === 'number' &&
    slowOptions.includes(candidate.slowPeriod) &&
    (candidate.average === 'sma' || candidate.average === 'ema')
  )
}

export function crossoverSignals(
  candles: Candle[],
  params: SignalParams,
): Signal[] {
  const closes = candles.map((candle) => candle.close)
  const average = params.average === 'ema' ? ema : sma
  const fast = average(closes, params.fastPeriod)
  const slow = average(closes, params.slowPeriod)
  const name = params.average.toUpperCase()

  const signals: Signal[] = []

  for (let index = 1; index < candles.length; index++) {
    const previousFast = fast[index - 1]
    const previousSlow = slow[index - 1]
    const currentFast = fast[index]
    const currentSlow = slow[index]

    if (
      previousFast === null ||
      previousSlow === null ||
      currentFast === null ||
      currentSlow === null
    ) {
      continue
    }

    const crossedUp = previousFast <= previousSlow && currentFast > currentSlow
    const crossedDown =
      previousFast >= previousSlow && currentFast < currentSlow

    if (crossedUp) {
      signals.push({
        index,
        time: candles[index].time,
        side: 'buy',
        price: candles[index].close,
        reason: `${name} ${params.fastPeriod} cruza por encima de ${name} ${params.slowPeriod}`,
      })
    } else if (crossedDown) {
      signals.push({
        index,
        time: candles[index].time,
        side: 'sell',
        price: candles[index].close,
        reason: `${name} ${params.fastPeriod} cruza por debajo de ${name} ${params.slowPeriod}`,
      })
    }
  }

  return signals
}
```

**Qué hace:** define la estrategia. Recibe las velas y los parámetros, y devuelve la lista de señales. **No dibuja nada y no guarda nada.**

**Por bloques:**

- **`RSI_PERIOD = 14`**: el periodo habitual del RSI. Una constante con nombre, en un solo lugar.
- **`fastOptions` y `slowOptions`**: las opciones de los selectores. **Toda opción rápida es menor que toda opción lenta** (la mayor, 12, es menor que la menor, 20). Esa regla es la que hace que no haga falta validar la combinación. **Si añades opciones, respétala.**
- **`averageOptions`**: los dos botones SMA/EMA.
- **`defaultSignalParams`**: con qué empieza quien entra por primera vez: SMA de 9 y 20.
- **`isSignalParams`**: igual que `isStrategy` y `isAppSettings` de la Fase 8: **verifica lo que se lea del almacenamiento**. Comprueba que los periodos estén entre las opciones permitidas. Si alguien (o una versión vieja de la app) dejó un valor raro, se usa el valor por defecto.
- **`crossoverSignals`**, el corazón:
  - Calcula las dos medias con la función elegida (`sma` o `ema`; las dos tienen la misma forma, por eso se pueden intercambiar en una variable).
  - Recorre las velas **desde la segunda** (`index = 1`), porque para detectar un cruce hay que comparar con la anterior.
  - Si cualquiera de los cuatro valores es `null` (calentamiento), **se salta** esa vela (`continue`).
  - **`crossedUp`**: antes la rápida estaba **por debajo o igual** que la lenta y ahora está **por encima**.
  - **`crossedDown`**: lo contrario.
  - Cada cruce produce una `Signal` con el número de vela, su hora, el lado, el cierre y un texto con el motivo.
  - El `else if` garantiza que una misma vela no produzca dos señales.
- **Sin mirar al futuro:** fíjate que la señal en la vela `index` solo usa `index` e `index - 1`. Nunca `index + 1`.

---

### Paso 5 — `src/chartLayout.ts` (archivo nuevo)

```ts
export const PLOT_X = { left: 84, right: 16 }
```

**Qué hace:** los márgenes **izquierdo y derecho** de los gráficos de velas y de RSI. Los dos los importan. Como cada vela y cada valor del RSI se colocan con la misma fórmula horizontal, **si comparten estos márgenes, quedan alineados**: la vela de las 14:00 y el RSI de las 14:00 están en la misma columna de la pantalla.

**Para editarlo:** si cambias estos números, **los dos gráficos se mueven juntos**. Ese es el objetivo.

---

### Paso 6 — `src/components/CandleChart.css` (añade al final)

No borres lo que ya tiene. **Añade esto al final**:

```css
.overlay {
  fill: none;
  stroke-width: 1.5;
  stroke-linejoin: round;
  stroke-linecap: round;
}

.overlay--fast {
  stroke: var(--overlay-fast);
}

.overlay--slow {
  stroke: var(--overlay-slow);
}

.signal {
  stroke: var(--bg);
  stroke-width: 1;
}

.signal--buy {
  fill: var(--signal-buy);
}

.signal--sell {
  fill: var(--signal-sell);
}

.chart__legend {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 16px;
  margin: 0 0 8px;
  font-size: 0.8rem;
  color: var(--text-muted);
}

.chart__swatch {
  display: inline-block;
  width: 14px;
  height: 3px;
  margin-right: 6px;
  vertical-align: middle;
  border-radius: 2px;
}

.chart__swatch--fast {
  background: var(--overlay-fast);
}

.chart__swatch--slow {
  background: var(--overlay-slow);
}

.legend__buy {
  color: var(--signal-buy);
}

.legend__sell {
  color: var(--signal-sell);
}

.rsi__zone {
  fill: var(--surface-raised);
  opacity: 0.35;
}

.rsi__line {
  fill: none;
  stroke: var(--accent);
  stroke-width: 1.5;
  stroke-linejoin: round;
  stroke-linecap: round;
}

.market__params {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
  gap: 16px;
  margin-bottom: 12px;
}

.market__rsi {
  margin-top: 8px;
}

.market__signals {
  margin-top: 16px;
}

.market__subtitle {
  margin: 0 0 8px;
  font-size: 1rem;
}
```

**Qué hace cada bloque:**

- **`.overlay`**: la forma común de las líneas de las medias. `fill: none` es importante: sin él, el navegador rellenaría el interior de la línea. Las puntas y uniones redondeadas la suavizan.
- **`.overlay--fast` / `--slow`**: el color de cada media, con las variables nuevas.
- **`.signal`**: los triángulos. El contorno del color del fondo (`stroke: var(--bg)`) los "separa" visualmente de la vela que tienen detrás.
- **`.signal--buy` / `--sell`**: el color de cada marcador.
- **`.chart__legend`** y **`.chart__swatch`**: la leyenda sobre el gráfico. Cada "muestra" es una rayita de 14×3 px del color de la línea.
- **`.legend__buy` / `__sell`**: el color de los símbolos ▲ y ▼ de la leyenda.
- **`.rsi__zone`**: la banda entre 30 y 70, apenas sombreada: la zona "normal".
- **`.rsi__line`**: la línea del RSI.
- **`.market__params`**: la cuadrícula de los tres controles, con el truco de siempre (`auto-fit`).
- **`.market__rsi`, `.market__signals`, `.market__subtitle`**: espacios y título de las secciones nuevas.

**No ejecutes `node scripts/check-css.mjs` como criterio.** En este proyecto está roto: reporta cientos de falsos positivos y escribe `&{line}` en lugar del número de línea (ver anexo A). Para comprobar que el CSS no rompe nada, ejecuta `pnpm build` y revisa los dos temas en el navegador. Si quieres una comprobación automática, el parche del anexo A deja el script utilizable.

---

### Paso 7 — `src/components/CandleChart.tsx` (reemplaza todo el contenido)

Es el de la Fase 9, con **tres añadidos**: acepta `overlays` y `signals` opcionales, los dibuja, y muestra una leyenda.

```tsx
import { useState, type PointerEvent as ReactPointerEvent } from 'react'
import './EquityChart.css'
import './CandleChart.css'
import { useElementWidth } from '../hooks/useElementWidth'
import { niceTicks } from '../chart'
import { PLOT_X } from '../chartLayout'
import { formatDateTime, formatPercent, formatPrice } from '../format'
import type { Candle, ChartOverlay, Signal } from '../types'

type CandleChartProps = {
  candles: Candle[]
  overlays?: ChartOverlay[]
  signals?: Signal[]
}

const HEIGHT = 320
const MARGIN = { top: 16, bottom: 28, ...PLOT_X }
const MARKER_GAP = 6
const MARKER_SIZE = 8

function changeClass(change: number): string {
  if (change > 0) return 'chart__change--positive'
  if (change < 0) return 'chart__change--negative'
  return ''
}

function CandleChart({
  candles,
  overlays = [],
  signals = [],
}: CandleChartProps) {
  const [containerRef, width] = useElementWidth<HTMLDivElement>()
  const [activeIndex, setActiveIndex] = useState<number | null>(null)

  if (candles.length === 0) {
    return (
      <div className="chart" ref={containerRef}>
        <p className="chart__empty">No hay velas para mostrar.</p>
      </div>
    )
  }

  const count = candles.length
  const lastIndex = count - 1
  const ticks = niceTicks(
    Math.min(...candles.map((candle) => candle.low)),
    Math.max(...candles.map((candle) => candle.high)),
    5,
  )
  const yMin = ticks[0]
  const yMax = ticks[ticks.length - 1]

  const plotWidth = Math.max(0, width - MARGIN.left - MARGIN.right)
  const plotHeight = HEIGHT - MARGIN.top - MARGIN.bottom
  const yBottom = MARGIN.top + plotHeight
  const slot = plotWidth / count
  const bodyWidth = Math.max(1, Math.min(14, slot * 0.7))

  function xOf(index: number): number {
    return MARGIN.left + (index + 0.5) * slot
  }

  function yOf(value: number): number {
    return MARGIN.top + (1 - (value - yMin) / (yMax - yMin)) * plotHeight
  }

  const shownIndex = Math.min(activeIndex ?? lastIndex, lastIndex)
  const shown = candles[shownIndex]
  const change = ((shown.close - shown.open) / shown.open) * 100

  const description = `Gráfico de velas de ${count} velas, de ${formatDateTime(candles[0].time)} a ${formatDateTime(candles[lastIndex].time)} UTC${
    signals.length > 0 ? `, con ${signals.length} señales` : ''
  }`

  function handlePointer(event: ReactPointerEvent<SVGSVGElement>) {
    const rect = event.currentTarget.getBoundingClientRect()
    const index = Math.floor((event.clientX - rect.left - MARGIN.left) / slot)
    setActiveIndex(Math.min(lastIndex, Math.max(0, index)))
  }

  return (
    <div className="chart" ref={containerRef}>
      <p className="chart__readout">
        <strong>{formatPrice(shown.close)}</strong>
        <span className={changeClass(change)}>
          {change > 0 ? '+' : ''}
          {formatPercent(change, 2)}
        </span>
        <span className="chart__ohlc">
          O {formatPrice(shown.open)} · H {formatPrice(shown.high)} · L{' '}
          {formatPrice(shown.low)} · C {formatPrice(shown.close)}
        </span>
        <span>{formatDateTime(shown.time)} UTC</span>
      </p>

      {(overlays.length > 0 || signals.length > 0) && (
        <p className="chart__legend">
          {overlays.map((overlay) => (
            <span key={overlay.id}>
              <span className={`chart__swatch chart__swatch--${overlay.kind}`} />
              {overlay.label}
            </span>
          ))}
          {signals.length > 0 && (
            <>
              <span>
                <span className="legend__buy">▲</span> Compra
              </span>
              <span>
                <span className="legend__sell">▼</span> Venta
              </span>
            </>
          )}
        </p>
      )}

      {width > 0 && (
        <svg
          className="chart__svg"
          width={width}
          height={HEIGHT}
          viewBox={`0 0 ${width} ${HEIGHT}`}
          role="img"
          aria-label={description}
          onPointerMove={handlePointer}
          onPointerDown={handlePointer}
          onPointerLeave={() => setActiveIndex(null)}
        >
          {ticks.map((tick) => (
            <g key={tick}>
              <line
                className="chart__grid"
                x1={MARGIN.left}
                x2={MARGIN.left + plotWidth}
                y1={yOf(tick)}
                y2={yOf(tick)}
              />
              <text
                className="chart__label"
                x={MARGIN.left - 8}
                y={yOf(tick)}
                textAnchor="end"
                dominantBaseline="middle"
              >
                {formatPrice(tick)}
              </text>
            </g>
          ))}

          {candles.map((candle, index) => {
            const isUp = candle.close >= candle.open
            const x = xOf(index)
            const bodyTop = yOf(Math.max(candle.open, candle.close))
            const bodyBottom = yOf(Math.min(candle.open, candle.close))

            return (
              <g
                key={candle.time}
                className={isUp ? 'candle candle--up' : 'candle candle--down'}
              >
                <line
                  className="candle__wick"
                  x1={x}
                  x2={x}
                  y1={yOf(candle.high)}
                  y2={yOf(candle.low)}
                />
                <rect
                  className="candle__body"
                  x={x - bodyWidth / 2}
                  y={bodyTop}
                  width={bodyWidth}
                  height={Math.max(1, bodyBottom - bodyTop)}
                />
              </g>
            )
          })}

          {overlays.map((overlay) => {
            const points = overlay.values
              .map((value, index) =>
                value === null ? null : `${xOf(index)},${yOf(value)}`,
              )
              .filter((point): point is string => point !== null)
              .join(' ')

            return (
              <polyline
                key={overlay.id}
                className={`overlay overlay--${overlay.kind}`}
                points={points}
              />
            )
          })}

          {signals.map((signal) => {
            const candle = candles[signal.index]
            if (!candle) return null

            const x = xOf(signal.index)
            const half = MARKER_SIZE / 2

            if (signal.side === 'buy') {
              const y = yOf(candle.low) + MARKER_GAP
              return (
                <polygon
                  key={`${signal.index}-${signal.side}`}
                  className="signal signal--buy"
                  points={`${x},${y} ${x - half},${y + MARKER_SIZE} ${x + half},${y + MARKER_SIZE}`}
                />
              )
            }

            const y = yOf(candle.high) - MARKER_GAP
            return (
              <polygon
                key={`${signal.index}-${signal.side}`}
                className="signal signal--sell"
                points={`${x},${y} ${x - half},${y - MARKER_SIZE} ${x + half},${y - MARKER_SIZE}`}
              />
            )
          })}

          <text
            className="chart__label"
            x={MARGIN.left}
            y={HEIGHT - 8}
            textAnchor="start"
          >
            {formatDateTime(candles[0].time)}
          </text>
          <text
            className="chart__label"
            x={MARGIN.left + plotWidth}
            y={HEIGHT - 8}
            textAnchor="end"
          >
            {formatDateTime(candles[lastIndex].time)}
          </text>

          {activeIndex !== null && (
            <line
              className="chart__cursor"
              x1={xOf(shownIndex)}
              x2={xOf(shownIndex)}
              y1={MARGIN.top}
              y2={yBottom}
            />
          )}
        </svg>
      )}
    </div>
  )
}

export default CandleChart
```

**Qué cambió respecto a la Fase 9 (son 5 cosas):**

1. **Los márgenes laterales vienen de `PLOT_X`**: `{ top: 16, bottom: 28, ...PLOT_X }`. Los tres puntos "esparcen" `left` y `right` dentro del objeto.
2. **Dos props opcionales**: `overlays` y `signals`, ambos con `= []` por defecto. Por eso **el gráfico sigue funcionando igual si no se los das**: el código de la Fase 9 no se rompe.
3. **La leyenda**: aparece solo si hay líneas o señales. Cada línea lleva una "muestra" de su color. La clase `chart__swatch--${overlay.kind}` se arma con el tipo (`fast` o `slow`).
4. **Las líneas de las medias**, justo **después de las velas** (lo que se dibuja después queda encima):
   - Cada línea convierte sus valores a pares `"x,y"` y **descarta los `null`** del calentamiento con `.filter(...)`. El `(point): point is string` le dice a TypeScript que, tras el filtro, ya no hay `null` en la lista.
   - Se dibuja con un `<polyline>`, igual que la curva del balance en la Fase 7.
5. **Los marcadores de señal**, después de las líneas:
   - Cada señal sabe el **número de su vela** (`signal.index`), así que se busca esa vela y se dibuja el triángulo en su `x`.
   - **Compra (▲):** el triángulo se coloca **debajo** del mínimo de la vela (`yOf(candle.low) + MARKER_GAP`), con la punta hacia arriba.
   - **Venta (▼):** **encima** del máximo, con la punta hacia abajo. Recuerda que en SVG la `y` crece hacia abajo: "debajo" significa una `y` **mayor**.
   - `if (!candle) return null` es una protección: si por algún motivo la señal apunta a una vela que no existe, no dibuja nada en vez de romper la pantalla.
   - Cada marcador es un `<polygon>` con tres puntos (la punta y los dos extremos de la base).
   - `key={`${signal.index}-${signal.side}`}`: la combinación identifica cada señal.

**Una limitación:** si una señal cae en una vela muy cerca del borde superior o inferior del gráfico, el triángulo puede salirse un poco del área de dibujo. Con la escala de `niceTicks`, que deja algo de margen, rara vez pasa. Es un detalle que se puede pulir (ver alternativas).

---

### Paso 8 — `src/components/RsiPanel.tsx` (archivo nuevo)

```tsx
import { useState, type PointerEvent as ReactPointerEvent } from 'react'
import './EquityChart.css'
import './CandleChart.css'
import { useElementWidth } from '../hooks/useElementWidth'
import { PLOT_X } from '../chartLayout'
import { formatDateTime, formatOrDash } from '../format'
import type { Series } from '../indicators'
import type { Candle } from '../types'

type RsiPanelProps = {
  candles: Candle[]
  values: Series
  period: number
}

const HEIGHT = 140
const MARGIN = { top: 12, bottom: 12, ...PLOT_X }
const LOW_LEVEL = 30
const HIGH_LEVEL = 70

function zoneLabel(value: number | null): string {
  if (value === null) return ''
  if (value >= HIGH_LEVEL) return `Zona alta (≥ ${HIGH_LEVEL})`
  if (value <= LOW_LEVEL) return `Zona baja (≤ ${LOW_LEVEL})`
  return ''
}

function RsiPanel({ candles, values, period }: RsiPanelProps) {
  const [containerRef, width] = useElementWidth<HTMLDivElement>()
  const [activeIndex, setActiveIndex] = useState<number | null>(null)

  const count = values.length

  if (count < 2 || candles.length !== count) {
    return (
      <div className="chart" ref={containerRef}>
        <p className="chart__empty">No hay datos suficientes para el RSI.</p>
      </div>
    )
  }

  const lastIndex = count - 1
  const plotWidth = Math.max(0, width - MARGIN.left - MARGIN.right)
  const plotHeight = HEIGHT - MARGIN.top - MARGIN.bottom
  const slot = plotWidth / count

  function xOf(index: number): number {
    return MARGIN.left + (index + 0.5) * slot
  }

  function yOf(value: number): number {
    return MARGIN.top + (1 - value / 100) * plotHeight
  }

  const linePoints = values
    .map((value, index) =>
      value === null ? null : `${xOf(index)},${yOf(value)}`,
    )
    .filter((point): point is string => point !== null)
    .join(' ')

  const shownIndex = Math.min(activeIndex ?? lastIndex, lastIndex)
  const shownValue = values[shownIndex]

  function handlePointer(event: ReactPointerEvent<SVGSVGElement>) {
    const rect = event.currentTarget.getBoundingClientRect()
    const index = Math.floor((event.clientX - rect.left - MARGIN.left) / slot)
    setActiveIndex(Math.min(lastIndex, Math.max(0, index)))
  }

  return (
    <div className="chart" ref={containerRef}>
      <p className="chart__readout">
        <span>RSI {period}:</span>
        <strong>{formatOrDash(shownValue, (value) => value.toFixed(1))}</strong>
        <span>{zoneLabel(shownValue)}</span>
        <span>{formatDateTime(candles[shownIndex].time)} UTC</span>
      </p>

      {width > 0 && (
        <svg
          className="chart__svg"
          width={width}
          height={HEIGHT}
          viewBox={`0 0 ${width} ${HEIGHT}`}
          role="img"
          aria-label={`Panel de RSI de ${period} periodos`}
          onPointerMove={handlePointer}
          onPointerDown={handlePointer}
          onPointerLeave={() => setActiveIndex(null)}
        >
          <rect
            className="rsi__zone"
            x={MARGIN.left}
            y={yOf(HIGH_LEVEL)}
            width={plotWidth}
            height={yOf(LOW_LEVEL) - yOf(HIGH_LEVEL)}
          />

          {[HIGH_LEVEL, LOW_LEVEL].map((level) => (
            <g key={level}>
              <line
                className="chart__grid"
                x1={MARGIN.left}
                x2={MARGIN.left + plotWidth}
                y1={yOf(level)}
                y2={yOf(level)}
              />
              <text
                className="chart__label"
                x={MARGIN.left - 8}
                y={yOf(level)}
                textAnchor="end"
                dominantBaseline="middle"
              >
                {level}
              </text>
            </g>
          ))}

          <polyline className="rsi__line" points={linePoints} />

          {activeIndex !== null && (
            <line
              className="chart__cursor"
              x1={xOf(shownIndex)}
              x2={xOf(shownIndex)}
              y1={MARGIN.top}
              y2={MARGIN.top + plotHeight}
            />
          )}
        </svg>
      )}
    </div>
  )
}

export default RsiPanel
```

**Qué hace:** un panel pequeño, **debajo** del gráfico de velas, que dibuja la línea del RSI con las zonas de 30 y 70.

**Lo que es igual que en los gráficos anteriores:** `useElementWidth`, escala `xOf` por "ranura", cursor con eventos de puntero, y el truco de `.filter((point): point is string => ...)` para quitar los `null`.

**Lo nuevo:**

- **La escala vertical es fija, de 0 a 100**: `yOf(value) = top + (1 − value / 100) × alto`. No hace falta `niceTicks`, porque el RSI siempre está entre 0 y 100.
- **`xOf` es idéntica a la de `CandleChart`** (`left + (index + 0.5) × slot`) y los dos usan `PLOT_X`. **Esa es la razón de que queden alineados.** Si algún día cambias una de las dos fórmulas pero no la otra, el panel se desalinea.
- **Los `null` del calentamiento** se descartan: la línea del RSI empieza en la vela 15, no en la primera. Con 100 velas, quedan 86 valores.
- **`zoneLabel`**: si el valor está en zona alta o baja, lo dice en texto, para no depender solo del dibujo. Es una descripción, **no una recomendación**: un RSI alto no significa "vende".
- **`formatOrDash`**: si el valor no existe (`null`), muestra "—", igual que en las tarjetas de indicadores.
- **La banda sombreada** (`.rsi__zone`) cubre la zona entre 30 y 70.
- **La guarda** `candles.length !== count`: el RSI y las velas deben tener el mismo largo. Si no, algo se calculó mal y se muestra un mensaje en vez de un gráfico desalineado.
- **El `period`** se pasa como prop solo para mostrarlo en el texto ("RSI 14") y en la descripción para lectores de pantalla.

---

### Paso 9 — `src/components/SignalsTable.tsx` (archivo nuevo)

```tsx
import './TradesTable.css'
import { sideLabels } from '../trades'
import { formatDateTime, formatPrice } from '../format'
import type { Signal } from '../types'

type SignalsTableProps = {
  signals: Signal[]
}

function SignalsTable({ signals }: SignalsTableProps) {
  return (
    <div className="table-wrap">
      <table className="trades">
        <thead>
          <tr>
            <th scope="col">Vela (UTC)</th>
            <th scope="col">Lado</th>
            <th scope="col" className="trades__num">
              Precio de referencia
            </th>
            <th scope="col">Motivo</th>
          </tr>
        </thead>

        <tbody>
          {signals.length === 0 && (
            <tr>
              <td colSpan={4} className="trades__empty">
                Esta estrategia no generó señales con estos datos.
              </td>
            </tr>
          )}

          {signals.map((signal) => (
            <tr key={`${signal.index}-${signal.side}`}>
              <td>{formatDateTime(signal.time)}</td>
              <td>
                <span className={`side side--${signal.side}`}>
                  {sideLabels[signal.side]}
                </span>
              </td>
              <td className="trades__num">{formatPrice(signal.price)}</td>
              <td>{signal.reason}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default SignalsTable
```

**Qué hace:** una tabla de las señales, **reutilizando los estilos de la tabla de operaciones** (`.table-wrap`, `.trades`, `.side`...). Por eso importa `TradesTable.css` de forma explícita: la dependencia queda escrita.

**Detalles:**

- **El estado vacío** es importante aquí: con ciertos parámetros y datos, la estrategia puede **no generar ninguna señal**. Eso no es un error, y la pantalla lo dice con claridad.
- **`sideLabels`** viene de la Fase 5 (`trades.ts`). Con el pre-flight 0.4.1 muestra **"Compra"** y **"Venta"**; sin ese cambio, verás `BUY`/`SELL` y la tabla de la sección 5 no coincidirá.
- **Las pastillas Compra y Venta** son las mismas de la tabla de operaciones, con los mismos colores.
- **`colSpan={4}`** debe coincidir con el **número de columnas** (4). Si añades o quitas una, cámbialo.

---

### Paso 10 — `src/components/MarketAnalysis.tsx` (archivo nuevo)

```tsx
import CandleChart from './CandleChart'
import RsiPanel from './RsiPanel'
import SignalsTable from './SignalsTable'
import { ema, rsi, sma } from '../indicators'
import { RSI_PERIOD, crossoverSignals } from '../signals'
import type { Candle, ChartOverlay, SignalParams } from '../types'

type MarketAnalysisProps = {
  candles: Candle[]
  params: SignalParams
}

function MarketAnalysis({ candles, params }: MarketAnalysisProps) {
  const closes = candles.map((candle) => candle.close)
  const average = params.average === 'ema' ? ema : sma
  const name = params.average.toUpperCase()

  const overlays: ChartOverlay[] = [
    {
      id: 'fast',
      label: `${name} ${params.fastPeriod}`,
      kind: 'fast',
      values: average(closes, params.fastPeriod),
    },
    {
      id: 'slow',
      label: `${name} ${params.slowPeriod}`,
      kind: 'slow',
      values: average(closes, params.slowPeriod),
    },
  ]

  const signals = crossoverSignals(candles, params)
  const rsiValues = rsi(closes, RSI_PERIOD)

  return (
    <>
      <CandleChart candles={candles} overlays={overlays} signals={signals} />

      <div className="market__rsi">
        <RsiPanel candles={candles} values={rsiValues} period={RSI_PERIOD} />
      </div>

      <div className="market__signals">
        <h3 className="market__subtitle">Señales ({signals.length})</h3>
        <SignalsTable signals={signals} />
      </div>

      <p className="disclaimer">
        Las señales son un ejemplo educativo (cruce de medias) y se confirman al
        cierre de cada vela. No son una recomendación de compra ni de venta.
      </p>
    </>
  )
}

export default MarketAnalysis
```

**Qué hace:** recibe las velas y los parámetros, **calcula todo** (medias, señales, RSI) y reparte los resultados a los tres componentes que los dibujan. No tiene estado propio: todo son **valores derivados**.

**Piezas:**

- **`const average = params.average === 'ema' ? ema : sma`**: una **función guardada en una variable**. `ema` y `sma` tienen la misma forma (`(valores, periodo) → lista`), así que se pueden intercambiar.
- **`overlays`**: las dos líneas a dibujar. Cada una lleva su etiqueta (por ejemplo, "SMA 9"), su tipo (`'fast'` o `'slow'`, que decide el color) y sus valores.
- **`signals`**: la lista de señales de la estrategia.
- **`rsiValues`**: la serie del RSI.
- **`<>...</>`**: un *fragmento*. Permite devolver varios elementos sin envolverlos en un `div` extra.
- **El número entre paréntesis** en "Señales (3)" es `signals.length`.
- **El aviso** recuerda dos cosas importantes: que es un ejemplo y que **no es una recomendación**.

> **Por qué las señales se calculan aquí y no dentro del gráfico:** el gráfico solo **dibuja** lo que le dan. Así, cuando en la Fase 11 el backtest necesite las mismas señales, llamará a la misma `crossoverSignals`, sin tener que sacarla de ningún componente.

---

### Paso 11 — `src/components/MarketSection.tsx` (reemplaza todo el contenido)

Es el de la Fase 9, **traducido al español**, con los **tres controles nuevos**, la opción `5 min` conservada y el uso de `MarketAnalysis`.

```tsx
import { useState } from 'react'
import './EquityChart.css'
import './CandleChart.css'
import MarketAnalysis from './MarketAnalysis'
import { useCandles } from '../hooks/useCandles'
import { useLocalStorageState } from '../hooks/useLocalStorageState'
import { marketDataSource } from '../market'
import { availablePairs } from '../strategy'
import {
  averageOptions,
  defaultSignalParams,
  fastOptions,
  isSignalParams,
  slowOptions,
} from '../signals'
import type { Interval, SignalParams } from '../types'

const SIGNAL_PARAMS_KEY = 'lixtrd:signal-params'

const intervalOptions: { id: Interval; label: string }[] = [
  { id: '5m', label: '5 min' },
  { id: '15m', label: '15 min' },
  { id: '1h', label: '1 h' },
  { id: '4h', label: '4 h' },
  { id: '1d', label: '1 día' },
]

const CANDLE_LIMIT = 100

function MarketSection() {
  const [pair, setPair] = useState<string>(availablePairs[0])
  const [timeframe, setTimeframe] = useState<Interval>('1h')
  const [reloadKey, setReloadKey] = useState(0)

  const [params, setParams] = useLocalStorageState<SignalParams>(
    SIGNAL_PARAMS_KEY,
    defaultSignalParams,
    isSignalParams,
  )

  const state = useCandles(
    marketDataSource,
    pair,
    timeframe,
    CANDLE_LIMIT,
    reloadKey,
  )

  return (
    <section className="section">
      <div className="section__header">
        <h2>Precio del mercado</h2>

        <div className="market__controls">
          <div className="segmented" role="group" aria-label="Par">
            {availablePairs.map((option) => (
              <button
                key={option}
                type="button"
                className={`segmented__option ${
                  pair === option ? 'segmented__option--active' : ''
                }`}
                aria-pressed={pair === option}
                onClick={() => setPair(option)}
              >
                {option}
              </button>
            ))}
          </div>

          <div className="segmented" role="group" aria-label="Temporalidad">
            {intervalOptions.map((option) => (
              <button
                key={option.id}
                type="button"
                className={`segmented__option ${
                  timeframe === option.id ? 'segmented__option--active' : ''
                }`}
                aria-pressed={timeframe === option.id}
                onClick={() => setTimeframe(option.id)}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="market__params">
        <div className="field">
          <label className="field__label" htmlFor="fast-period">
            Media rápida
          </label>
          <div className="field__control">
            <select
              id="fast-period"
              value={params.fastPeriod}
              onChange={(event) =>
                setParams({ ...params, fastPeriod: Number(event.target.value) })
              }
            >
              {fastOptions.map((option) => (
                <option key={option} value={option}>
                  {option} velas
                </option>
              ))}
            </select>
          </div>
          <p className="field__help">Reacciona rápido a los cambios.</p>
        </div>

        <div className="field">
          <label className="field__label" htmlFor="slow-period">
            Media lenta
          </label>
          <div className="field__control">
            <select
              id="slow-period"
              value={params.slowPeriod}
              onChange={(event) =>
                setParams({ ...params, slowPeriod: Number(event.target.value) })
              }
            >
              {slowOptions.map((option) => (
                <option key={option} value={option}>
                  {option} velas
                </option>
              ))}
            </select>
          </div>
          <p className="field__help">Marca la tendencia de fondo.</p>
        </div>

        <div className="field">
          <span className="field__label" id="average-label">
            Tipo de media
          </span>
          <div className="field__control">
            <div
              className="segmented"
              role="group"
              aria-labelledby="average-label"
            >
              {averageOptions.map((option) => (
                <button
                  key={option.id}
                  type="button"
                  className={`segmented__option ${
                    params.average === option.id
                      ? 'segmented__option--active'
                      : ''
                  }`}
                  aria-pressed={params.average === option.id}
                  onClick={() => setParams({ ...params, average: option.id })}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>
          <p className="field__help">
            SMA: promedio simple. EMA: da más peso a lo reciente.
          </p>
        </div>
      </div>

      {state.status === 'loading' && (
        <div className="chart chart__status" role="status">
          Cargando velas…
        </div>
      )}

      {state.status === 'error' && (
        <div className="chart chart__status chart__status--error" role="alert">
          <p>No se pudieron cargar los datos: {state.message}</p>
          <button
            type="button"
            className="btn"
            onClick={() => setReloadKey((key) => key + 1)}
          >
            Reintentar
          </button>
        </div>
      )}

      {state.status === 'success' && (
        <MarketAnalysis candles={state.data} params={params} />
      )}

      <p className="disclaimer">
        Fuente: {marketDataSource.name}. {marketDataSource.description} Horas
        en UTC.
      </p>
    </section>
  )
}

export default MarketSection
```

**Qué cambió respecto a la Fase 9 (son 6 cosas):**

1. **Imports nuevos:** `MarketAnalysis`, `useLocalStorageState`, y lo que sale de `signals.ts`. Ya **no** se importa `CandleChart` aquí: lo usa `MarketAnalysis`.
2. **Los textos pasan a español:** "Market Price" → "Precio del mercado", "Loading candles..." → "Cargando velas…", "Retry" → "Reintentar", etc. El paso 11 es el que salda esta deuda de traducción.
3. **Se conserva la opción `5 min`:** la Fase 9 la tenía y no hay motivo para perderla. Las otras etiquetas se vuelven más legibles ("1 h", "1 día").
4. **Los parámetros viven aquí y se recuerdan:**
   ```tsx
   const [params, setParams] = useLocalStorageState<SignalParams>(
     SIGNAL_PARAMS_KEY, defaultSignalParams, isSignalParams)
   ```
   Es el mismo hook de la Fase 8: funciona como `useState`, pero guarda en el navegador y **valida** lo leído. Se guardan con su propia clave (`lixtrd:signal-params`).
5. **Los tres controles nuevos**, reutilizando los estilos de formulario (`.field`, `.field__control`...) y el selector segmentado:
   - **Media rápida** y **media lenta**: `<select>` con las opciones fijas.
   - **Tipo de media**: un selector segmentado SMA/EMA.
   - Al cambiar uno, se llama a `setParams({ ...params, fastPeriod: ... })`: se copian todos los parámetros y se cambia solo el que tocó. Es el mismo patrón de `handleChange` de la Fase 4.
   - `Number(event.target.value)`: un `<select>` siempre entrega **texto**; hay que convertirlo a número.
6. **El caso de éxito** ahora dibuja `<MarketAnalysis candles={state.data} params={params} />`.

**Un detalle de accesibilidad:** para el "Tipo de media", que no es un campo sino un grupo de botones, el título es un `<span>` con `id`, y el grupo lo referencia con `aria-labelledby`. Así los lectores de pantalla leen "Tipo de media, grupo".

---

### Paso 12 (opcional) — Pruebas automáticas con Vitest

Las pruebas **dejan por escrito lo que esperas** y una máquina lo verifica en un segundo. Para el motor de backtest, serán imprescindibles; es mejor estrenarlas ahora, con funciones sencillas.

> **Nota de compatibilidad:** a la fecha de esta revisión, **Vitest 5.x** soporta Vite 8 (el proyecto usa Vite 8). Si en el futuro `pnpm add -D vitest` instala una versión que no sea compatible, revisa los avisos de `peerDependencies` de pnpm y fija una versión que sí lo sea.

**1. Instalar** (en la terminal, en la raíz del proyecto):

```powershell
pnpm add -D vitest
```

Si pnpm avisa de build scripts ignorados (por ejemplo, `esbuild`), ejecuta `pnpm approve-builds`, selecciona `esbuild` y vuelve a intentar.

**2. Añadir el comando** en `package.json`, dentro de `"scripts"`:

```json
"test": "vitest run"
```

(No olvides la coma que separa la línea anterior.) También puedes ejecutar las pruebas sin tocar `package.json` con `pnpm exec vitest run`.

**3. Crear `src/indicators.test.ts`:**

```ts
import { describe, expect, it } from 'vitest'
import { ema, rsi, sma } from './indicators'
import { crossoverSignals } from './signals'
import type { Candle, SignalParams } from './types'

function candlesFromCloses(closes: number[]): Candle[] {
  return closes.map((close, index) => ({
    time: index * 3_600_000,
    open: close,
    high: close,
    low: close,
    close,
    volume: 0,
  }))
}

describe('sma', () => {
  it('calcula el promedio de las últimas N velas', () => {
    expect(sma([1, 2, 3, 4, 5], 3)).toEqual([null, null, 2, 3, 4])
  })

  it('con periodo 1 devuelve los mismos valores', () => {
    expect(sma([1, 2, 3], 1)).toEqual([1, 2, 3])
  })

  it('devuelve solo nulos si no hay datos suficientes', () => {
    expect(sma([1, 2], 5)).toEqual([null, null])
  })
})

describe('ema', () => {
  it('empieza con la media simple y luego suaviza', () => {
    expect(ema([2, 4, 6, 8, 6], 3)).toEqual([null, null, 4, 6, 6])
  })

  it('devuelve solo nulos si no hay datos suficientes', () => {
    expect(ema([1, 2], 5)).toEqual([null, null])
  })
})

describe('rsi', () => {
  const closes = [
    44.34, 44.09, 44.15, 43.61, 44.33, 44.83, 45.1, 45.42, 45.84, 46.08, 45.89,
    46.03, 45.61, 46.28, 46.28, 46.0, 46.03, 46.41, 46.22, 45.64,
  ]

  it('el primer valor coincide con el cálculo hecho a mano', () => {
    expect(rsi(closes, 14)[14]).toBeCloseTo(70.46, 1)
  })

  it('el segundo valor aplica el suavizado de Wilder', () => {
    expect(rsi(closes, 14)[15]).toBeCloseTo(66.25, 1)
  })

  it('no hay valor mientras no haya suficientes velas', () => {
    expect(rsi([1, 2, 3], 14)).toEqual([null, null, null])
  })

  it('un precio plano da 50', () => {
    expect(rsi(new Array(20).fill(10), 14)[19]).toBe(50)
  })

  it('un precio que solo sube da 100', () => {
    const rising = Array.from({ length: 20 }, (_, index) => index)
    expect(rsi(rising, 14)[19]).toBe(100)
  })

  it('un precio que solo baja da 0', () => {
    const falling = Array.from({ length: 20 }, (_, index) => 20 - index)
    expect(rsi(falling, 14)[19]).toBe(0)
  })
})

describe('crossoverSignals', () => {
  const params: SignalParams = { fastPeriod: 2, slowPeriod: 3, average: 'sma' }
  const closes = [10, 10, 10, 10, 9, 8, 7, 8, 9, 10, 11, 12, 11, 10, 9]

  it('detecta una venta, una compra y otra venta', () => {
    const signals = crossoverSignals(candlesFromCloses(closes), params)

    expect(signals.map((signal) => [signal.index, signal.side])).toEqual([
      [4, 'sell'],
      [8, 'buy'],
      [13, 'sell'],
    ])
  })

  it('un precio plano no genera señales', () => {
    const flat = new Array(10).fill(5)
    expect(crossoverSignals(candlesFromCloses(flat), params)).toEqual([])
  })

  it('no usa datos del futuro', () => {
    const full = crossoverSignals(candlesFromCloses(closes), params)
    const partial = crossoverSignals(candlesFromCloses(closes.slice(0, 10)), params)

    expect(full.filter((signal) => signal.index < 10)).toEqual(partial)
  })
})
```

**4. Ejecutarlas:**

```powershell
pnpm test
```

Debe decir que **todas pasan**. Si pnpm se queja de que no encuentra el comando `test`, revisa que lo añadiste dentro de `"scripts"` y que guardaste `package.json`.

**Qué hace cada pieza:**

- **`describe` y `it`**: agrupan y nombran las pruebas. Se leen como frases: "sma: calcula el promedio de las últimas N velas".
- **`expect(valor).toEqual(esperado)`**: "espero que este valor sea igual a este otro". Si no, la prueba falla y te dice qué recibió.
- **`toBeCloseTo(70.46, 1)`**: para decimales, "casi igual" (con una tolerancia). Compararlos con exactitud es una mala idea por la forma en que la computadora guarda los decimales.
- **`candlesFromCloses`**: una pequeña ayuda que fabrica velas **a partir de solo los cierres**, porque las medias solo usan el cierre.
- **La prueba de "no usa datos del futuro"**: calcula las señales con 15 velas y con solo las primeras 10. Las señales de las 10 primeras velas **deben ser idénticas**. Si la estrategia usara una vela futura para decidir, **esta prueba fallaría**. Es la protección más importante de todo el proyecto.
- **El RSI contra el cálculo a mano**: `70.46` es el número del paso 3. Si cambias la fórmula por error, esta prueba lo detecta.

---

## 5. Cómo probarlo

> **Condiciones para que los números coincidan:** fuente **sintética**, `CANDLE_LIMIT = 100`, BTC/USDT, 1 h, SMA 9/20. Si usas Binance, la pantalla funciona igual pero las fechas, los precios y el número de señales cambian. Ver 0.3.

Guarda todo y entra a **Estadísticas**, sección **Precio del mercado**.

### 5.1 Con los valores por defecto

**Con BTC/USDT, 1 h, SMA 9 y 20:**

1. Sobre las velas se ven **dos líneas**: una naranja (SMA 9) y una celeste (SMA 20). La rápida es más "nerviosa"; la lenta, más suave. Las dos **empiezan más tarde** que las velas (calentamiento): la SMA 9 en la vela 9 y la SMA 20 en la 20.
2. Encima de las velas hay una **leyenda**: "SMA 9", "SMA 20", "▲ Compra", "▼ Venta".
3. Hay **2 triángulos**: ▼ el **29 de diciembre a las 17:00** y ▲ el **30 de diciembre a las 09:00**.
4. La tabla de **Señales (2)** dice:

| Vela (UTC) | Lado | Precio de referencia | Motivo |
|---|---|---|---|
| Dec 29, 17:00 | Venta | 60,862.24 | SMA 9 cruza por debajo de SMA 20 |
| Dec 30, 09:00 | Compra | 61,032.03 | SMA 9 cruza por encima de SMA 20 |

5. Debajo, el **panel de RSI**. Por defecto, la fila superior dice **RSI 14: 54.2**. El RSI de estos datos oscila entre **34.8 y 71.9**: entra brevemente en la **zona alta** el 31 de diciembre a las 16:00 (71.1) y a las 17:00 (71.9), y **nunca** entra en la zona baja. Si pasas el mouse por esas dos velas, el texto debe decir "Zona alta (≥ 70)".
6. La línea del RSI empieza en la **vela 15** (Dec 28, 10:00), no en la primera: con 100 velas quedan **86 valores**. Eso es el calentamiento, no un error.
7. **Alineación:** pasa el mouse sobre el panel de RSI y sobre el gráfico de velas: el cursor de cada uno está **en la misma columna** que la vela correspondiente.
8. **Pasa el mouse** por el gráfico de velas: la línea vertical y los datos O, H, L, C siguen funcionando como en la Fase 9. La última vela (Dec 31, 23:00) debe leer `62,674.74`, `-0.42%`, `O 62,936.44 · H 62,987.70 · L 62,521.97 · C 62,674.74`.
9. **Recarga** el navegador: tus tres controles **se recuerdan**.
10. Cambia a **tema claro**: las líneas, los triángulos y las zonas del RSI cambian y se leen bien.
11. Achica la ventana: los dos gráficos se adaptan y siguen alineados.
12. Cambia de par o de temporalidad: ves "Cargando velas…" y luego todo se recalcula. La opción **5 min** debe seguir existiendo.

### 5.2 Cambiando los controles

**Siempre con la fuente sintética y 100 velas:**

13. Cambia **Tipo de media** a **EMA**: las líneas cambian de forma y siguen habiendo **2 señales**, pero en otros momentos: ▼ el **29 de diciembre a las 19:00** (60,739.91) y ▲ el **30 de diciembre a las 08:00** (61,155.98). La EMA reacciona antes, así que los cruces no caen en la misma vela que con SMA.
14. Vuelve a **SMA** y cambia la temporalidad a **4 h**: con **BTC/USDT 4 h y SMA 9/20** deberías ver **8 señales** (4 compras y 4 ventas). Con **EMA 9/20** en 4 h, **6 señales** (3 y 3).
15. Con **ETH/USDT 1 h y SMA 9/20**, **6 señales** (3 compras y 3 ventas).
16. Con **SOL/USDT 1 h y SMA 9/20**, **0 señales**. La tabla debe decir **"Esta estrategia no generó señales con estos datos."** Eso **no es un error**: es el estado vacío. Es la combinación más rápida para comprobar ese mensaje.
17. Una lenta de **50** no garantiza cero señales: con 100 velas hay 50 valores y puede haber cruces. Por ejemplo, BTC/USDT 1 h SMA 9/50 da **2 señales**. No uses "lenta de 50" como sinónimo de "sin señales"; usa SOL 1 h.
18. Cambia de par, temporalidad y tipo de media varias veces y **recarga**: los controles deben conservar el último valor válido. Si guardaste una combinación y luego cambias las opciones de `signals.ts`, `isSignalParams` descarta lo viejo y vuelve al valor por defecto.

### 5.3 Con las pruebas automáticas (paso 12)

19. `pnpm test` muestra **todas las pruebas en verde**.
20. **Rompe algo a propósito** para ver que las pruebas sirven: en `crossoverSignals`, cambia

```ts
const crossedUp = previousFast <= previousSlow && currentFast > currentSlow
```

por

```ts
const crossedUp = previousFast <= previousSlow && currentFast >= currentSlow
```

Ejecuta `pnpm test`: la prueba "detecta una venta, una compra y otra venta" debe fallar, porque aparece una compra extra en el índice 3. **Devuélvelo a como estaba** y vuelve a ejecutar hasta ver todo en verde.

21. Ejecuta `pnpm build` otra vez: el archivo de pruebas también se revisa por TypeScript. Si el build falla por la prueba, corrige el tipo que indica el error; no excluyas el archivo sin entender por qué.

### 5.4 Checklist rápido

- [ ] Dos líneas (naranja y celeste) sobre las velas.
- [ ] Leyenda con SMA 9, SMA 20, ▲ Compra, ▼ Venta.
- [ ] Dos triángulos en Dec 29, 17:00 y Dec 30, 09:00.
- [ ] Tabla "Señales (2)" con 60,862.24 y 61,032.03.
- [ ] RSI 14: 54.2, con zona alta al final y nunca zona baja.
- [ ] Los dos gráficos alineados al pasar el mouse.
- [ ] Los controles se recuerdan al recargar.
- [ ] Los dos temas se leen bien.
- [ ] `pnpm test` y `pnpm build` en verde.

---

## 6. Si algo falla

| Síntoma | Causa probable | Qué hacer |
|---|---|---|
| No aparecen las medias | `MarketSection` no usa `MarketAnalysis` (paso 11), o `MarketAnalysis` no pasa `overlays` a `CandleChart`. | Revisa el paso 10 y el 11; comprueba que `overlays.length > 0`. |
| No aparecen los triángulos | `signals` no se pasa a `CandleChart`; o la estrategia no genera señales con esos parámetros y datos. | Mira la tabla: si dice 0, no hay nada que dibujar. Prueba BTC/USDT 1 h SMA 9/20. |
| Las líneas empiezan en la primera vela y caen al suelo | Estás poniendo `0` en vez de `null` durante el calentamiento. | Devuelve `null` en los índices sin datos; nunca `0`. |
| Las líneas se ven desplazadas respecto de las velas | `values` no tiene el mismo largo que `candles`, o `xOf` en las líneas no es la misma que la de las velas. | Comprueba que cada serie tenga `candles.length` elementos y usa la misma fórmula `xOf`. |
| Rojo en `MarketSection` sobre `useLocalStorageState` | Falta ese hook de la Fase 8 o la ruta del `import` está mal. | Verifica `src/hooks/useLocalStorageState.ts` y el import `../hooks/useLocalStorageState`. |
| Rojo en `RsiPanel` sobre `Series` | Falta `export type Series` en `indicators.ts` o el `import type`. | Añade `export type Series = (number | null)[]` y usa `import type { Series }`. |
| Rojo en `MarketAnalysis` o `CandleChart` sobre `ChartOverlay`/`Signal` | Falta el tipo en `types.ts` o el `import type`. | Revisa el paso 1 y los imports del paso 7/10. |
| El panel de RSI dice "No hay datos suficientes para el RSI." | `rsiValues` y `candles` tienen largos distintos, o hay menos de 2 velas. | Comprueba que `rsi(closes, RSI_PERIOD).length === candles.length`. |
| El RSI no está alineado con las velas | Los dos no usan `PLOT_X` (`chartLayout.ts`), o la fórmula de `xOf` es distinta. | Usa `{ top, bottom, ...PLOT_X }` en los dos y la misma fórmula `left + (index + 0.5) * slot`. |
| Las líneas, triángulos o zonas no tienen color | Faltan las 4 variables nuevas en `index.css` (paso 2), o están solo en uno de los dos temas. | Añádelas a `:root` y a `:root[data-theme='light']`. |
| En el tema claro, algunas cosas se ven oscuras | Falta alguna de las 4 variables en el bloque `:root[data-theme='light']`. | Repite el paso 2 para el tema claro. |
| Los triángulos de compra están encima de la vela y los de venta debajo | Se invirtió el signo de `MARKER_GAP` o la orientación del triángulo. | Recuerda que en SVG la `y` crece hacia abajo: compra = `yOf(low) + MARKER_GAP`, venta = `yOf(high) - MARKER_GAP`. |
| El selector no cambia nada | `onChange` no llama a `setParams`, o falta `Number(...)` y se guarda texto. | Usa `setParams({ ...params, fastPeriod: Number(event.target.value) })`. |
| Al recargar, los controles vuelven a los de por defecto | `isSignalParams` rechaza lo guardado: los valores no están en `fastOptions`/`slowOptions`. | Revisa la lista de opciones y borra la clave `lixtrd:signal-params` si quedó un valor viejo. |
| Las señales no coinciden con las de la sección 5 | Estás usando Binance, cambiaste `synthetic.ts` o `CANDLE_LIMIT`, o hay un error en `sma`, `ema` o `crossoverSignals`. | Vuelve a la fuente sintética y a 100 velas; compara con el anexo B y con las pruebas. |
| La tabla muestra `BUY`/`SELL` en vez de `Compra`/`Venta` | No aplicaste el pre-flight 0.4.1. | Cambia `sideLabels` en `src/trades.ts` o ajusta la tabla esperada. |
| El texto "No hay velas..." o "No hay datos..." no se ve | `.chart__empty` usa `color: var(--surface)`, igual que el fondo. | Aplica el pre-flight 0.4.3: usa `var(--text-muted)`. |
| El cambio negativo del gráfico no es rojo | `EquityChart.css` tiene `.color__change--negative` en vez de `.chart__change--negative`. | Aplica el pre-flight 0.4.2. |
| `check-css.mjs` reporta cientos de problemas | El script está roto: `definedVars`/`definedClasses` nunca se llenan y el reporte imprime `&{line}`. | **Ignóralo** y usa `pnpm build` + revisión visual. Anexo A. |
| `pnpm test` falla con "Cannot find module 'vitest'" | No se instaló o pnpm bloqueó el build script. | `pnpm add -D vitest`; si hace falta, `pnpm approve-builds` y acepta `esbuild`. |
| `pnpm test` dice que no encuentra pruebas | El archivo no termina en `.test.ts` o está fuera de `src`. | Renómbralo a `src/indicators.test.ts`. |
| `pnpm build` falla por el archivo de pruebas | `tsconfig.app.json` incluye `src`, así que también revisa el test. | Corrige el error de tipos que reporta; no excluyas el test sin una razón. |
| Una prueba de decimales falla por muy poco | Comparaste floats con `toEqual`. | Usa `toBeCloseTo(valor, decimales)`. |
| `pnpm add -D vitest` avisa de peer dependencies | La versión de Vitest y la de Vite no encajan. | Fija una versión compatible; Vitest 5.x soporta Vite 8. |
| La carga nunca termina | La fuente no responde (Binance bloqueado, red caída) o el `AbortController` no cancela. | Usa la fuente sintética para probar; revisa `useCandles` y el estado de error. |
| El pie dice "Synthetic data. Hardcoded candlesticks..." | La metadata de la fuente está en inglés. | Aplica el pre-flight 0.4.4 o ignóralo. |
| Desapareció la opción `5 min` | El paso 11 se copió sin esa opción. | Añade `{ id: '5m', label: '5 min' }` a `intervalOptions`. |
| El gráfico aparece muy abajo en Estadísticas | `Stats.tsx` coloca `<MarketSection />` al final. | Opcional: muévela después de "Indicadores de riesgo" (0.4.5). |

---

## 7. Alternativas de funcionalidad y de estética

Esta sección es para que veas **qué más se podría hacer**, qué tan difícil es y qué archivos tocaría. Ninguna es obligatoria.

**Dificultad:** 🟢 fácil (unos minutos) · 🟡 media (varios pasos) · 🔴 más compleja (necesita planificación)

### 7.1 Alternativas de funcionalidad

| Idea | Qué agrega | Dificultad | Qué archivos tocaría | Notas |
|---|---|---|---|---|
| **Periodos libres** | Escribir cualquier número para las medias. | 🟡 | `types.ts`, `signals.ts`, `MarketSection.tsx` | Hay que validar que la rápida sea menor que la lenta y que ambos sean enteros ≥ 2. Ver reto 1. |
| **RSI como filtro** | No comprar con el RSI muy alto, no vender con el RSI muy bajo. | 🟡 | `signals.ts`, `types.ts`, pruebas | La función recibe también la serie del RSI. Ver reto 2. |
| **Más indicadores** | MACD, bandas de Bollinger, ATR. | 🟡 cada uno | `indicators.ts`, un panel nuevo | Todos son funciones puras. El **ATR** (volatilidad) servirá para tamaños de posición y stops en el backtest. |
| **Más estrategias** | Ruptura de máximos (Donchian), reversión con RSI. | 🟡 | `signals.ts`, `types.ts`, `MarketSection.tsx` | Todas tienen la forma "velas y parámetros → señales". Un selector de estrategia hace falta. Ver reto 3. |
| **Resumen de señales** | "3 señales: 1 compra, 2 ventas". | 🟢 | `MarketAnalysis.tsx` | Valores derivados con `.filter`. Ver reto 4. |
| **Mostrar/ocultar indicadores** | Casillas para ocultar las medias o el RSI. | 🟢 | `MarketSection.tsx`, `MarketAnalysis.tsx` | Dos estados nuevos y renderizado condicional. |
| **Cantidad de velas configurable** | Elegir 50, 100, 200. | 🟢 | `MarketSection.tsx` | Con más velas aparecen más señales; con 50 y una media lenta de 50, ninguna (calentamiento). |
| **Mover la sección** | Ver el gráfico antes en Estadísticas. | 🟢 | `Stats.tsx` | Mueve `<MarketSection />` después de "Indicadores de riesgo". No cambia la lógica. |
| **Exportar señales a CSV** | Descargar la tabla. | 🟡 | `SignalsTable.tsx`, utilidad nueva | Un `Blob` con texto separado por comas. |
| **Señales en otras pantallas** | Ver la última señal en el Panel o en Ejecutar bot. | 🟡 | `App.tsx`, `Dashboard.tsx`, `BotRun.tsx` | Habría que subir el cálculo o el estado a `App`. |
| **Alertas** | Avisar cuando aparece una señal nueva. | 🟡 | `useCandles.ts`, un hook nuevo | Tiene sentido con datos en vivo (Fase 12). |
| **Multi-temporalidad** | Confirmar una señal de 1 h con la tendencia de 4 h. | 🔴 | casi todo | Dos fuentes de velas y alinearlas en el tiempo. |
| **Una "confianza" de la señal** | Un número entre 0 y 1. | 🔴 | — | **Cuidado:** el vault proponía fórmulas con pesos inventados. Una cifra de confianza sin medición detrás es decoración. Solo tiene sentido derivada de resultados reales de backtest. |
| **Usar una librería de indicadores** | Ahorrarte escribir las funciones. | 🟡 | `indicators.ts` | **Verifica sus fórmulas** contra tus pruebas: distintas librerías usan variantes distintas (por ejemplo, del RSI o de la semilla de la EMA). |

### 7.2 Alternativas de estética

| Idea | Qué cambia | Dificultad |
|---|---|---|
| **Cambiar los colores** | Las 4 variables nuevas, en los dos temas. | 🟢 |
| **Líneas más gruesas o más finas** | `stroke-width` de `.overlay`. | 🟢 |
| **Marcadores más grandes** | `MARKER_SIZE` y `MARKER_GAP`. | 🟢 |
| **Letras en lugar de triángulos** | "C" y "V" dentro de un círculo. | 🟡 |
| **Panel de RSI más alto o más bajo** | `HEIGHT` de `RsiPanel`. | 🟢 |
| **Sin banda sombreada en el RSI** | Quitar el `<rect className="rsi__zone">`. | 🟢 |
| **Líneas verticales punteadas en cada señal** | Dibujar una línea desde la vela hasta el panel del RSI. | 🟡 |
| **Resaltar la zona entre las medias** | Un área entre las dos líneas, de un color distinto si la rápida está arriba o abajo. | 🔴 |
| **Transición al cambiar parámetros** | Que las líneas se muevan suavemente. | 🔴 |
| **Tema claro** | Ya funciona con las variables. | 🟢 |

#### Cómo se hacen las fáciles

**Colores.** En `index.css`, cambia los valores de `--overlay-fast`, `--overlay-slow`, `--signal-buy` y `--signal-sell`, **en los dos bloques**. Recomendación: cambia uno a la vez y mira el resultado. Para texto o líneas sobre fondo oscuro busca contraste alto; sobre fondo claro, tonos más oscuros.

**Línea más gruesa.** En `CandleChart.css`, en `.overlay`:

```css
stroke-width: 2.5;
```

**Marcadores más grandes.** En `CandleChart.tsx`:

```tsx
const MARKER_GAP = 8
const MARKER_SIZE = 12
```

**Panel de RSI más alto.** En `RsiPanel.tsx`:

```tsx
const HEIGHT = 200
```

**Sin banda sombreada.** En `RsiPanel.tsx`, borra el bloque:

```tsx
<rect
  className="rsi__zone"
  x={MARGIN.left}
  y={yOf(HIGH_LEVEL)}
  width={plotWidth}
  height={yOf(LOW_LEVEL) - yOf(HIGH_LEVEL)}
/>
```

Si quieres, quita también la regla `.rsi__zone` del CSS (el script no se queja de reglas que sobran).

---

## 8. Qué puedes cambiar libremente y qué no

### 🟢 Libre: no rompe nada

- Los **valores** de las 4 variables nuevas (en los dos bloques).
- Grosores, tamaños y textos del CSS de esta fase.
- `HEIGHT` del panel de RSI y del gráfico, `MARKER_SIZE`, `MARKER_GAP`.
- Los **textos**: motivos de las señales, ayudas, leyenda, aviso.
- Los valores por defecto de `defaultSignalParams` (siempre que estén entre las opciones).
- `RSI_PERIOD`, **si también actualizas las pruebas** (los valores esperados dependen del periodo 14).

### 🟡 Con cuidado: hay que tocar varios lugares a la vez

- **Añadir opciones a `fastOptions` o `slowOptions`.** Toda opción rápida **debe seguir siendo menor** que toda opción lenta, o podrías tener una media rápida más lenta que la "lenta". Y `isSignalParams` usa las mismas listas: lo guardado que quede fuera de las opciones se descarta.
- **Añadir un indicador.** Función pura en `indicators.ts`, su prueba, y dónde dibujarlo.
- **Añadir una estrategia.** Una función nueva con la forma `(velas, parámetros) → señales`, parámetros propios en `types.ts` y validación en `signals.ts`.
- **Cambiar la forma de `Signal`.** Afecta a `signals.ts`, a `CandleChart` (marcadores), a `SignalsTable` y a las pruebas.
- **Cambiar `PLOT_X`.** Los dos gráficos se mueven juntos; es seguro. Pero si cambias el margen izquierdo, revisa que quepan las etiquetas del eje.
- **Cambiar el número de columnas de `SignalsTable`.** Hay que cambiar también el `colSpan`.
- **Cambiar `sideLabels`.** Afecta a la tabla de operaciones y a la de señales. Si lo pasas a español, hazlo en un solo lugar (`trades.ts`), no dupliques mapas.
- **Cambiar `CANDLE_LIMIT` o el `END_TIME` de `synthetic.ts`.** No rompe la app, pero cambia todos los valores esperados de la sección 5 y del anexo B. Si lo haces, actualiza la documentación o no uses esos números como prueba.
- **Cambiar de fuente de datos (`binanceSource` ↔ `syntheticSource`).** La lógica es la misma; los números no. Anota cuál usaste al comparar resultados.

### 🔴 No lo cambies sin ajustar lo demás

- **`null` en el calentamiento.** Nunca lo reemplaces por 0: dibujaría una línea falsa, y las señales se calcularían contra valores inventados.
- **Que la señal de la vela `i` use solo datos hasta la `i`.** Cualquier "mejora" que mire la vela siguiente **invalida la estrategia** y el backtest. La prueba "no usa datos del futuro" existe para protegerte de eso.
- **El `<=` y el `>` del cruce.** Cambiarlos puede duplicar o perder señales.
- **Que las series tengan el mismo largo que las velas.** Todo el dibujo se basa en que el valor `i` pertenece a la vela `i`.
- **Que `xOf` sea la misma fórmula en `CandleChart` y en `RsiPanel`**, con los mismos márgenes. Es lo que mantiene la alineación.
- **Que `ema` y `sma` mantengan la misma firma** `(valores, periodo) → lista`: `MarketAnalysis` las intercambia en una variable.
- **Que las funciones de `indicators.ts` y `signals.ts` sigan siendo puras.** No leas `localStorage`, la hora ni nada del navegador dentro de ellas: el backtest las ejecutará millones de veces y esperará resultados repetibles.
- **Las 4 variables en los dos bloques.** Una variable en un solo tema es un error silencioso.

---

## 9. Retos opcionales

**Reto 1 — Periodos libres** 🟡

Que se puedan **escribir** los periodos de las medias, en vez de elegirlos de una lista.

Pistas, sin la solución:

1. Reutiliza el patrón del formulario de Ajustar bot (Fase 4): un borrador en texto, validación y un botón **Guardar**.
2. Reglas: ambos enteros, mínimo 2, la rápida **estrictamente menor** que la lenta, y un máximo razonable (con 100 velas, un periodo de 150 no calcula nada).
3. Actualiza `isSignalParams` para validar con esas reglas en vez de con las listas.
4. Piensa qué pasa con lo ya guardado.

**Reto 2 — El RSI como filtro** 🟡

Que la estrategia **ignore** una compra si el RSI está en zona alta (≥ 70) y una venta si está en zona baja (≤ 30).

Pistas:

1. Añade un parámetro `useRsiFilter` (verdadero o falso) a `SignalParams` y un interruptor en la pantalla.
2. `crossoverSignals` necesita la serie del RSI: calcúlala dentro, con `rsi(closes, RSI_PERIOD)`.
3. **Cuidado con el calentamiento:** si el RSI en esa vela es `null`, decide si se deja pasar la señal o se descarta. Es una decisión de diseño; anótala.
4. **Escribe las pruebas primero**: una serie donde el cruce ocurra con el RSI alto, y verifica que no haya señal.
5. Piensa qué hace esto con `isSignalParams` y con lo ya guardado.

**Reto 3 — Una segunda estrategia** 🟡

Escribe `breakoutSignals(candles, params)`: compra cuando el cierre supera el **máximo de las últimas N velas**, y vende cuando cae por debajo del **mínimo** de las últimas N.

Pistas:

1. Es otra función pura, con la misma forma que `crossoverSignals`: velas y parámetros entran, señales salen.
2. **Cuidado con mirar al futuro:** el máximo de las "últimas N velas" debe **excluir la vela actual** (si no, el cierre nunca podría superarlo).
3. Añade un selector de estrategia en `MarketSection`. Piensa cómo guardar los parámetros de cada una.
4. Escribe sus pruebas, **incluida la de "no usa datos del futuro"**.

**Reto 4 — Resumen de señales** 🟢

Muestra, sobre la tabla, un resumen como **"3 señales: 1 compra y 2 ventas"**.

Pistas:

1. Son valores derivados: `signals.filter((signal) => signal.side === 'buy').length`.
2. Cuida el singular y el plural ("1 señal", "2 señales").
3. Piensa qué dice cuando no hay ninguna.

Si te atoras en alguno, pégame tu código y lo revisamos.

---

## 10. Lo que viene

**Fase 11 — Motor de backtest.**

Es la pieza central de todo el proyecto, y también la más delicada. Va a convertir esas **señales** en **operaciones con resultado**, recorriendo muchas velas:

- Una **señal** se convierte en una **orden**, que se **ejecuta en la apertura de la vela siguiente** (nunca en el mismo cierre que la generó).
- Una **posición** abierta se cierra por **stop loss**, **take profit** o por la señal contraria. Los porcentajes salen de lo que ya configuraste en **Ajustar bot** (`Strategy`).
- Cada operación paga **comisión** y un **deslizamiento** estimado.
- El resultado es una lista de `Trade` que **Estadísticas ya sabe mostrar**: la tabla, los indicadores de riesgo y la curva del balance, con datos del backtest en vez de los de ejemplo.
- **Pruebas automáticas** del motor, con casos pequeños que verifiquen cada regla (qué pasa si el stop loss y el take profit caen en la misma vela, qué pasa si la señal llega en la última vela, etc.).

**Dos tareas previas que ya conocemos** (están en la hoja de ruta): `Trade.time` pasará de texto `'HH:MM'` a una marca de tiempo, para poder abarcar varios días, y el Panel dejará de tener cifras escritas a mano.

**Para escribir la Fase 11 para tu caso** (y no para uno genérico), me ayudaría saber:

1. **Tu mercado inicial**: ¿cripto, forex/CFD, futuros, acciones? Cambian las comisiones, los horarios y el tamaño mínimo de las operaciones.
2. **Tu camino de ejecución**: ¿broker o exchange con API, o MetaTrader 5? Si es MT5, el backtest puede apoyarse también en su *Strategy Tester*.
3. **Cuántas horas por semana** puedes dedicar, para convertir las horas en fechas.

Mientras tanto, las Fases 10 y 11 funcionan con los datos sintéticos, así que no hace falta que decidas nada para seguir.

---

## Anexo A — `check-css.mjs`: qué pasa y cómo arreglarlo

**Conclusión corta:** no uses el script como criterio de aceptación en esta fase. Está roto y sus avisos no son fiables. Usa `pnpm build` y revisión visual.

### A.1 Los dos errores

1. **El número de línea.** `report` hace:

```js
problems.push(`${file}:&{line} ${message}`)
```

`&{line}` no es una interpolación; debería ser `${line}`. Por eso todos los mensajes dicen `&{line}`.

2. **Los conjuntos nunca se llenan.** `definedVars` y `definedClasses` se crean como `new Set()`, pero no hay ningún código que añada elementos. Entonces:
   - cualquier `var(--lo-que-sea)` se reporta como "undefined variable";
   - cualquier clase BEM usada en TSX se reporta como "not in any CSS".

El resultado son ~249 falsos positivos, mezclados con cualquier error real. No sirve para distinguir.

### A.2 Qué usar mientras tanto

```powershell
pnpm exec tsc --noEmit -p tsconfig.app.json
pnpm build
```

Y a ojo:

- cambia entre tema oscuro y claro;
- revisa que las 4 variables nuevas estén en los dos bloques;
- busca `var(--` en el CSS nuevo y confirma que la variable existe en `index.css`;
- abre la consola del navegador: un `var()` inexistente no lanza error, pero el color no aparece.

### A.3 Parche mínimo (opcional)

Si quieres reparar el script, haz estos tres cambios.

**1. Corrige el reporte:**

```js
problems.push(`${file}:${line} ${message}`)
```

**2. Llena los conjuntos antes de validar.** Justo después de crear `definedVars` y `definedClasses`, añade:

```js
for (const text of cssText.values()) {
  for (const match of text.matchAll(/(--[\w-]+)\s*:/g)) {
    definedVars.add(match[1])
  }
  for (const match of text.matchAll(/\.([_a-zA-Z][\w-]*)/g)) {
    definedClasses.add(match[1])
  }
}
```

**3. Vuelve a ejecutar:**

```powershell
node scripts/check-css.mjs
```

Seguirá habiendo falsos positivos para clases construidas en tiempo de ejecución (por ejemplo, `chart__swatch--${overlay.kind}`): el script ve el texto `chart__swatch--` y no puede saber qué variantes existen. Esas se ignoran a mano. Si el script empieza a reportar un problema nuevo y concreto, investígalo; si vuelve a imprimir cientos de líneas, algo del parche no se aplicó.

> **No es parte de la Fase 10.** Es una herramienta de apoyo. No bloquees el avance por ella.

---

## Anexo B — Valores verificados (fuente sintética, 100 velas)

Estos números se generaron con el `synthetic.ts` actual:

- hash FNV-1a con offset `2166136261`;
- `mulberry32` con semilla `` hashString(`${pair}|${interval}`) ``;
- `END_TIME = Date.UTC(2026, 0, 1)`;
- `CANDLE_LIMIT = 100` en `MarketSection.tsx`.

Si cambias cualquiera de esos cuatro elementos, la tabla deja de aplicar. No es un fallo: es la naturaleza de un generador determinista.

| Par | Temporalidad | Media | Rápida/Lenta | Señales | Detalle |
|---|---|---|---|---|---|
| BTC/USDT | 1 h | SMA | 9/20 | **2** (1 compra, 1 venta) | ▼ Dec 29, 17:00 · 60,862.24; ▲ Dec 30, 09:00 · 61,032.03 |
| BTC/USDT | 1 h | EMA | 9/20 | **2** (1, 1) | ▼ Dec 29, 19:00 · 60,739.91; ▲ Dec 30, 08:00 · 61,155.98 |
| BTC/USDT | 4 h | SMA | 9/20 | **8** (4, 4) | — |
| BTC/USDT | 4 h | EMA | 9/20 | **6** (3, 3) | — |
| ETH/USDT | 1 h | SMA | 9/20 | **6** (3, 3) | — |
| SOL/USDT | 1 h | SMA | 9/20 | **0** | Estado vacío de la tabla |
| BTC/USDT | 1 h | SMA | 9/50 | **2** (1, 1) | No es un caso sin señales |

**Velas de BTC/USDT 1 h:**

- Primera: **Dec 27, 2025, 20:00 UTC**.
- Última: **Dec 31, 2025, 23:00 UTC**.
- Último cierre: **62,674.74**.
- RSI 14 final: **54.2**.
- RSI mínimo/máximo: **34.8 / 71.9**.
- Zona alta: **Dec 31, 16:00 (71.1)** y **Dec 31, 17:00 (71.9)**.
- Zona baja: **ninguna**.
- Valores del RSI: **86** (100 velas − 14 cambios).

**Cómo reproducirlo:**

1. Pon `marketDataSource = syntheticSource` (0.3).
2. Deja `CANDLE_LIMIT = 100`.
3. Abre Estadísticas → Precio del mercado.
4. Selecciona el par y la temporalidad de la fila.
5. Compara el número de señales y la primera/última fila de la tabla.

Si el número coincide pero los precios no, revisaste una fuente distinta. Si el número no coincide, compara tu `indicators.ts` y `signals.ts` con los pasos 3 y 4, o ejecuta las pruebas del paso 12.

---

## Anexo C — Checklist final de la fase

- [ ] `pnpm exec tsc --noEmit -p tsconfig.app.json` pasa.
- [ ] `pnpm build` pasa.
- [ ] `pnpm dev` muestra la sección traducida.
- [ ] Dos medias y leyenda.
- [ ] Dos triángulos en BTC/USDT 1 h SMA 9/20.
- [ ] Tabla de señales con los valores del anexo B.
- [ ] RSI alineado, con zonas 30/70.
- [ ] Controles persistidos.
- [ ] Tema oscuro y claro legibles.
- [ ] `pnpm test` en verde (si hiciste el paso 12).
- [ ] `check-css.mjs` no se usó como criterio.
