# LIXTRD MarkII — Resumen de Contexto y Progreso

## Visión General
LIXTRD MarkII es una plataforma de trading multi-activo hand-made, enhanced y expandido, derivada del repositorio original `rumbocrp/LIXTRD`. El objetivo es reimplementar y mejorar la arquitectura original con una paleta visual Matrix Green, navegación móvil reducida y soporte para criptomonedas, memecoins, futuros, índices y metales preciosos.

## Estructura del Vault Obsidian
El vault se encuentra en: `C:\Users\Bitbase\OneDrive\Documents\BITBASE\FLARE\lixtrd\obsidian-vault`

Contiene 13 sesiones progresivas indexadas por WikiLinks:

```
00-visión-general.md → 01-arquitectura.md → 02-tema-matrix.md → 03-nav-movil.md → 04-datos.md → 05-motor-señales.md → 06-dashboard.md → 07-riesgo-auditoria.md → 08-memecoins.md → 09-futuros-indices.md → 10-metales.md → 11-despliegue.md → 12-roadmap.md
```

## Estado Actual
Todas las sesiones (00-12) están en estado `pending`, listas para ser trabajadas en orden progresivo. Cada sesión bloquea la siguiente y utiliza backlinks WikiLinks para mantener la conectividad entre archivos.

## Filosofía de Desarrollo
Hecho a mano, mejorado y expandido.

A diferencia del repo original que es un sistema listo para usar, LIXTRD MarkII será:
1. **Hecho a mano:** Cada línea de código, cada estilo CSS, cada decisión de UI será revisada y mejorada.
2. **Mejorado:** Matrix Green theme, nav móvil compacta, mejor DX (developer experience).
3. **Expandido:** Soporta activos que el original no tocaba: memecoins, metales precious, futuros diversificados.

## Recursos y Referencias
- Repositorio original: `https://github.com/rumbocrp/LIXTRD`
- Tema visual: Matrix Green (verde oscuro exacto `#000000`/`#00FF41`, verde pálido claro `#F0FFF4`/`#006400`)
- CSS override: `src/index.css` y `src/theme-matrix.css` (carga posterior a `index.css` para ganar cascada)
- MobileNav: `src/components/MobileNav.tsx` + `src/components/MobileNav.css`
- Fix Sidebar: `sidebar--nav` → `sidebar__nav` en `src/components/Sidebar.tsx:28`
- Sin modificar archivos originales: `index.css`, `App.css`, `Sidebar.css`, `App.tsx` se mantienen intactos; solo se añaden nuevos archivos y 3 micro-edits.

## Próximos Pasos
1. Clonar el repositorio original: `git clone https://github.com/rumbocrp/LIXTRD.git`
2. Abrir Obsidian y apuntar al vault: `C:\Users\Bitbase\OneDrive\Documents\BITBASE\FLARE\lixtrd\obsidian-vault`
3. Comenzar la sesión 00: `00-visión-general.md`
4. Aplicar los fixes de tema y nav (tutorial LEGO previo)
5. Avanzar sesión por sesión hasta el despliegue final (roadmap.md)

## Nota de No-Modificación
Ningún archivo CSS/TS original de la aplicación LIXTRD fue alterado o borrado. Los cambios consisten en añadir 2 archivos CSS nuevos, 1 archivo TSX de navegación móvil, 1 línea de importación en `main.tsx` y 3 micro-edits en `Sidebar.tsx` (clase, import, inserción de componente).

---
*Vault generado para trabajo progresivo sin interrupciones. Cada sesión es independiente pero conectada por backlinks WikiLinks.*