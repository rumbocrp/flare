# 05 - Motor de Señales e IA Híbrida LIXTRD Mark II

## Objetivo

Construir el motor de decisión que combina reglas expertas, estadística avanzada y detección de anomalías para generar señales de trading en todos los grupos de activos. Motor híbrido: deterministic rules + probabilistic ML.

## Componentes del Motor

### 1. Reglas Expertas (Deterministic)

Lógica basada en patrones técnicos y configuraciones de mercado:

- **Breakout detection**: Precio rompe resistencia/soporte con volumen
- **MA crossovers**: Medias móviles simples (SMA) y exponenciales (EMA)
- **RSI zones**: Sobrecompra (>70) y sobreventa (<30)
- **Volume spikes**: Activación por anomalía de volumen
- **Horario filters**: Solo operar en sesiones configuradas

### 2. Estadística Avanzada

Análisis de frecuencia y probabilidad:

- **Historical success rate**: Tasa de éxito histórica por patrón
- **Expected value**: EV = (prob_win * size_win) - (prob_loss * size_loss)
- **Z-score**: Cuántos desviaciones estándar del promedio
- **Correlation analysis**: Evitar señales contradictorias en múltiples activos

### 3. Detección de Anomalías (ML Ligero)

Motor de IA híbrido sin modelos pesados:

- **Isolation Forest**: Detectar outliers en series de precios
- **Simple moving average residuals**: Errores del modelo baseline
- **Threshold configuration**: Umbrales configurables por activo (confianza 0.0-1.0)
- **Shadow mode**: Modo simulación-only, sin operaciones reales

## Flujo de Señal

```mermaid
flowchart TD
    A[Datos de Mercado] --> B[Preprocesamiento]
    B --> C[Reglas Expertas]
    B --> D[Estadística]
    B --> E[Anomalías IA]
    C --> F[Señal Candidate]
    D --> F
    E --> F
    F --> G[Filtro de Confianza]
    G -->|umbral OK| H[Señal Aprobada]
    G -->|umbral bajo| I[Descartar]
    H --> J[Modo Shadow / Ejecución]
```

## Configuración de Confianza

Cada señal lleva un campo `confidence` (0.0 a 1.0) calculado como:

```
confidence = 0.4 * regla_expertas + 0.3 * estadística + 0.3 * anomalía_ia
```

El usuario puede configurar umbral mínimo en la UI (por defecto 0.6 para modo real, 0.3 para modo shadow).

## Integración con Base de Datos

- Cada señal guardada en `SQLite tabla signals` con:
  - symbol, type, side (buy/sell), price, confidence
  - timestamp, activo_group, status (pending/accepted/rejected)
  - auditoría completa para review post-operación

## Próximos Pasos

- Integrar con ingestión de datos (sesión 04)
- Conectar con dashboard de señales (sesión 06)
- Configurar umbrales por grupo de activo
- Implementar modo shadow con reporte de precisión histórica