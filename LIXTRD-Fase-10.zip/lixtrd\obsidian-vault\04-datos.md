# 04 - Ingestión de Datos Multi-Activo LIXTRD Mark II

## Objetivo

Integrar fuentes de datos para todos los grupos de activos: criptomonedas, memecoins, futuros, índices y metales preciosos. Arquitectura de ingestión combinando APIs REST y WebSocket.

## Fuentes de Datos por Grupo de Activos

### Criptomonedas

- **Binance WebSocket**: velas en tiempo real para pares principales (BTC/USDT, ETH/USDT)
- **CoinGecko REST**: precios base, metadata, market caps para altcoins y memecoins
- **Horarios**: 24/7 con pausas cortas

### Memecoins

- **CoinGecko**: listing de memecoins (DOGE, SHIB, PEPE, FLOKI, etc.)
- **Extracción adicional**: APIs comunitarias, scraping controlado de CoinMarketCap
- **Consideraciones**: alta volatilidad, liquidez variable, hours de trading extensos

### Futuros e Índices

- **Yahoo Finance REST**: velas S&P 500 (US500), NASDAQ futuros, commodities
- **Proveedores especializados**: datos de futuros de CME, ICE para índices y commodities
- **Horarios**: sesiones diferenciadas (horarios de mercado tradicionales)

### Metales Preciosos

- **Yahoo Finance**: XAUUSD (oro), XAGUSD (plata)
- **Fuentes LBMA**: precios oficiales,fixing prices
- **Relación Oro/Plata**: tracking y métricas derivadas

## Arquitectura de Ingestión

```mermaid
flowchart TD
    Data_Sources -->|REST| API_Gateway
    Data_Sources -->|WebSocket| WS_Gateway
    API_Gateway -->|Normalize| Data_Buffer
    WS_Gateway -->|Normalize| Data_Buffer
    Data_Buffer -->|Persist| SQLite_DB
    Data_Buffer -->|Push| Frontend_Via_REST
    SQLite_DB -->|Query| Backend_Logic
```

### Componentes Clave

1. **Feed module** (`sistema_luces/feed/`): Ingesta normalizada unificada
2. **Config multi-activo** (`sistema_luces/config/`): Mapeo de símbolos por grupo
3. **Health checks**: Validación continua de conectividad y latencia
4. **Rate limiting**: Control de peticiones a APIs públicas

## Formato de Datos Normalizado

Cada dato entrante se normaliza a esquema común:

```json
{
  "symbol": "BTCUSDT",
  "type": "crypto|memecoin|future|index|metal",
  "price": 67421.50,
  "change": +2.34,
  "changePercent": 0.0035,
  "timestamp": 1700000000000,
  "source": "binance|coingecko|yahoo|coinbase",
  "metadata": {
    "volume": "12345.67",
    "high": "67800.00",
    "low": "67000.00"
  }
}
```

## Próximos Pasos

- Implementar conectores para cada grupo de activos
- Diseñar schema SQLite para auditoría multi-activo
- Integrar con motor de señales (siguiente sesión)
- Manejo de horarios de mercado diferenciados