# 08 - Expansión a Memecoins LIXTRD Mark II

## Objetivo

Extender la plataforma LIXTRD para soportar memecoins (DOGE, SHIB, PEPE, FLOKI, etc.) con análisis técnico adaptado, métricas de volatilidad y estrategias de trading diferenciadas a criptomonedas mayores.

## Diferencias Cripto vs Memecoins

### Características de Memecoins

| Característica | Cripto Mayor (BTC/ETH) | Memecoins |
|----------------|------------------------|-----------|
| **Capitalización** | Miles de millones | Millones o menos |
| **Volatilidad** | Moderada (10-20% diario) | Extremadamente alta (30-100% diario) |
| **Liquidez** | Alta, spreads bajos | Baja, spreads altos |
| **Horarios** | 24/7 con actividad institucional | 24/7 trading retail puro |
| **Manipulación** | Menor, mercados más maduros | Mayor, pumps and dumps posibles |
| **Volumen** | Alto, global | Variable, comunitario |

### Adaptaciones del Motor de Señales

1. **Umbrales de confianza más bajos**: Por defecto 0.4 (vs 0.6 para crypto) por volatilidad
2. **Stop-loss más amplio**: Percentual mayor para evitar stops premature
3. **Take-profit escalonado**: Metas múltiples por niveles de resistencia
4. **Filtrado de volumen mínimo**: Descartar señales con volumen por debajo del percentil 20

### Indicadores Adaptados

- **Volatility-adjusted RSI**: RSI con período dinámico según volatilidad reciente
- **Volume-weighted average price (VWAP) intradía**: Para memecoins con volumen esporádico
- **Meme sentiment score**: Análisis de redes sociales (Twitter/X, Reddit) como factor adicional

## Integración de Fuentes de Datos

### CoinGecko (principal)

- `GET /coins/markets` con filtros: vs_currency=usd, order=market_cap_desc
- Identificar memecoins por name o symbol: DOGE, SHIB, PEPE, FLOKI, BONK, WIF
- `GET /coins/{id}/market_chart` para datos históricos

### Sentiment Analysis (adicional)

- Twitter API v2: búsqueda de menciones $PEPE, $DOGE, etc.
- Reddit API: r/cryptocurrency, r/dogecoin, r/pepecoin
- Scraping controlado de sitios de news de memecoins
- **Peso**: 20% del score de señal total

### Price Feeds

- Binance WebSocket para pares principales de memecoins (DOGE/USDT, SHIB/USDT)
- Fallback a CoinGecko REST cada 5 minutos para precio de referencia
- Normalización a esquema común (ver sesión 04)

## Estrategias de Trading para Memecoins

### 1. Range Trading (rango lateral)

- Identificar soporte/resistencia claros
- Entrar en rebotes en soporte, salir en resistencia
- Position size reducido por alta volatilidad
- Objetivo: 2-4% por operación

### 2. Breakout with Volume Confirmation

- Esperar rompimiento de resistencia con volumen ↑↑
- Confirmación con aumento de volumen confirmado
- Stop-loss por debajo del rango anterior
- Target: 5-8% (breakouts de memecoins pueden ser fuertes)

### 3. Momentum Fade (desvanecimiento de momentum)

- Entrar cuando el momentum se está agotando (RSI extreme + volumen decreciente)
- Ideal para pumps rápidos y correcciones
- Máximo 1-2% por operación

## Configuración por Defecto Memecoins

```json
{
  "min_confidence": 0.4,
  "max_exposure": 15,
  "max_drawdown": -3,
  "max_signals_per_hour": 3,
  "volatility_adjustment": true,
  "sentiment_weight": 0.2,
  "min_volume_percentile": 20,
  "stop_loss_pct": 8,
  "take_profit_pcts": [3, 5, 8]
}
```

## Riesgos Específicos Memecoins

1. **Rug pulls**: Proyecto abandonado repentino - mitigación: verificar liquidez bloqueada, audits de contrato
2. **Liquidez insoportante**: No poder salir sin slippage enorme - mitigación: verificar volume 24h, order book depth
3. **Pumps y dumps coordinados**: Evitar operar justo después de menciones virales - mitigación: delay de 15-30 min después de viralización
4. **Actualizaciones de contrato**: Memecoins con contratos renovables - verificarse dirección del contrato en exploradores (BscScan, Etherscan)

## Próximos Pasos

- Implementar conectores CoinGecko y Binance para memecoins
- Agregar sentimiento social como factor de señal
- Configurar umbrales diferenciados por grupo de activo
- Probar estrategias en modo shadow antes de real
- Integrar con dashboard y gestión de riesgo