import { useState, type PointerEvent as ReactPointerEvent } from 'react'
import './EquityChart.css'
import './CandleChart.css'
import { useElementWidth } from '../hooks/useElementWidth'
import { niceTicks } from '../chart'
import { formatDateTime, formatPercent, formatPrice } from '../format'
import type { Candle } from '../types'

type CandleChartProps = {
  candles: Candle[]
}

const HEIGHT = 320
const MARGIN = { top: 16, right: 16, bottom: 28, left: 84 }

function changeClass(change: number): string {
  if (change > 0) return 'chart__change--positive'
  if (change < 0) return 'chart__change--negative'
  return ''
}

function CandleChart({ candles }: CandleChartProps) {
  const [containerRef, width] = useElementWidth<HTMLDivElement>()
  const [activeIndex, setActiveIndex] = useState<number | null>(null)

  if (candles.length === 0) {
    return (
      <div className='chart' ref={containerRef}>
        <p className='chart__empty'>No candlesticks to show.</p>
      </div>
    )
  }

  const count = candles.length
  const lastIndex = count - 1
  const ticks = niceTicks(
    Math.min(...candles.map((candle) => candle.low)),
    Math.max(...candles.map((candle) => candle.high)),
    5,
  )

  const yMin = ticks[0]
  const yMax = ticks[ticks.length - 1]

  const plotWidth = Math.max(0, width - MARGIN.left - MARGIN.right)
  const plotHeight = HEIGHT - MARGIN.top - MARGIN.bottom
  const yBottom = MARGIN.top + plotHeight
  const slot = plotWidth / count
  const bodyWidth = Math.max(1, Math.min(14, slot * 0.7))

  function x0f(index: number): number {
    return MARGIN.left + (index + 0.5) * slot
  }

  function y0f(value: number): number {
    return MARGIN.top + (1 - (value - yMin) / (yMax - yMin)) * plotHeight
  }

  const shownIndex = Math.min(activeIndex ?? lastIndex, lastIndex)
  const shown = candles[shownIndex]
  const change = ((shown.close - shown.open) / shown.open) * 100

  function handlePointer(event: ReactPointerEvent<SVGSVGElement>) {
    const rect = event.currentTarget.getBoundingClientRect()
    const index = Math.floor((event.clientX - rect.left - MARGIN.left) / slot)
    setActiveIndex(Math.min(lastIndex, Math.max(0, index)))
  }

  return (
    <div className='chart' ref={containerRef}>
      <p className='chart__readout'>
        <strong>{formatPrice(shown.close)}</strong>
        <span className={changeClass(change)}>
          {change > 0 ? '+' : ''}
          {formatPercent(change, 2)}
        </span>
        <span className='chart__ohlc'>
          O {formatPrice(shown.open)} · H {formatPrice(shown.high)} · L{' '}
          {formatPrice(shown.low)} · C {formatPrice(shown.close)}
        </span>
        <span>{formatDateTime(shown.time)} UTC</span>
      </p>

      {width > 0 && (
        <svg
          className="chart__svg"
          width={width}
          height={HEIGHT}
          viewBox={`0 0 ${width} ${HEIGHT}`}
          role="img"
          aria-label={`Gráfico de velas de ${count} velas, de ${formatDateTime(candles[0].time)} a ${formatDateTime(candles[lastIndex].time)} UTC`}
          onPointerMove={handlePointer}
          onPointerDown={handlePointer}
          onPointerLeave={() => setActiveIndex(null)}
        >
          {ticks.map((tick) => (
            <g key={tick}>
              <line
                className="chart__grid"
                x1={MARGIN.left}
                x2={MARGIN.left + plotWidth}
                y1={y0f(tick)}
                y2={y0f(tick)}
              />
              <text
                className="chart__label"
                x={MARGIN.left - 8}
                y={y0f(tick)}
                textAnchor="end"
                dominantBaseline="middle"
              >
                {formatPrice(tick)}
              </text>
            </g>
          ))}

          {candles.map((candle, index) => {
            const isUp = candle.close >= candle.open
            const x = x0f(index)
            const bodyTop = y0f(Math.max(candle.open, candle.close))
            const bodyBottom = y0f(Math.min(candle.open, candle.close))

            return (
              <g
                key={candle.time}
                className={isUp ? 'candle candle--up' : 'candle candle--down'}
              >
                <line
                  className="candle__wick"
                  x1={x}
                  x2={x}
                  y1={y0f(candle.high)}
                  y2={y0f(candle.low)}
                />
                <rect
                  className="candle__body"
                  x={x - bodyWidth / 2}
                  y={bodyTop}
                  width={bodyWidth}
                  height={Math.max(1, bodyBottom - bodyTop)}
                />
              </g>
            )
          })}

          <text
            className="chart__label"
            x={MARGIN.left}
            y={HEIGHT - 8}
            textAnchor="start"
          >
            {formatDateTime(candles[0].time)}
          </text>
          <text
            className="chart__label"
            x={MARGIN.left + plotWidth}
            y={HEIGHT - 8}
            textAnchor="end"
          >
            {formatDateTime(candles[lastIndex].time)}
          </text>

          {activeIndex !== null && (
            <line
              className="chart__cursor"
              x1={x0f(shownIndex)}
              x2={x0f(shownIndex)}
              y1={MARGIN.top}
              y2={yBottom}
            />
          )}
        </svg>
      )}
    </div>
  )
}

export default CandleChart
