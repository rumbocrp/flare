import { useState } from 'react'
import './EquityChart.css'
import './CandleChart.css'
import CandleChart from './CandleChart'
import { useCandles } from '../hooks/useCandles'
import { marketDataSource } from '../market'
import { availablePairs } from '../strategy'
import type { Interval } from '../types'

const intervalOptions: { id: Interval, label: string }[] = [
  { id: '5m', label: '5m' },
  { id: '15m', label: '15m' },
  { id: '1h', label: '1h' },
  { id: '4h', label: '4h' },
  { id: '1d', label: '1D' },
]

const CANDLE_LIMIT = 100

function MarketSection() {
  const [pair, setPair] = useState<string>(availablePairs[0])
  const [timeframe, setTimeframe] = useState<Interval>('1h')
  const [reloadKey, setReloadKey] = useState(0)

  const state = useCandles(
    marketDataSource,
    pair,
    timeframe,
    CANDLE_LIMIT,
    reloadKey,
  )

  return (
    <section className='section'>
      <div className='section__header'>
        <h2>Market Price</h2>

        <div className='market__controls'>
          <div className='segmented' role='group' aria-label='Pair'>
            {availablePairs.map((option) => (
              <button
                key={option}
                type='button'
                className={`segmented__option ${pair === option ? 'segmented__option--active' : ''
                  }`}
                aria-pressed={pair === option}
                onClick={() => setPair(option)}
              >
                {option}
              </button>
            ))}
          </div>

          <div className='segmented' role='group' aria-label='Temporarity'>
            {intervalOptions.map((option) => (
              <button
                key={option.id}
                type='button'
                className={`segmented__option ${
                  timeframe === option.id ? 'segmented__option--active' : ''
                  }`}
                aria-pressed={timeframe === option.id}
                onClick={() => setTimeframe(option.id)}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {state.status === 'error' && (
        <div className='chart chart__status chart__status--error' role='alert'>
          <p>Cannot load data: {state.message}</p>
          <button
            type='button'
            className='btn'
            onClick={() => setReloadKey((key) => key + 1)}
          >
            Retry
          </button>
        </div>
      )}

      {state.status === 'loading' && (
        <div className="chart chart__status" role="status">
          Loading candles...
        </div>
      )}

      {state.status === "success" && <CandleChart candles={state.data} />}

      <p className='disclaimer'>
        Source: {marketDataSource.name}. {marketDataSource.description}
        UTC Time.
      </p>
    </section>
  )
}

export default MarketSection
