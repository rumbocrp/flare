# 06 - Dashboard Web en Tiempo Real LIXTRD Mark II

## Objetivo

Construir una interfaz dashboard responsiva que muestre en tiempo real los estados de operación, luces de mercado, métricas de rendimiento y señales generadas para todos los grupos de activos.

## Arquitectura del Dashboard

### Capas Frontend

1. **Capa de Datos en Tiempo Real**
   - WebSocket connections por grupo de activos
   - Reconexión automática con backoff exponencial
   - Buffer local de último minuto para offline recovery

2. **Capa de Presentación**
   - React components anidados
   - Custom hooks para estado de datos
   - CSS variables para tema Matrix Green

3. **Capa de Estado**
   - `useState` para datos actuales
   - `useEffect` para suscripciones WS
   - `useLocalStorageState` para preferencias persistentes

### Componentes Principales

#### Dashboard Principal

- Layout: sidebar izquierdo + contenido principal + navbar superior
- Header: fecha/hora actual, modo (shadow/real), conexión WS status
- Main area: grid responsive de tarjetas por grupo de activo

#### Cards por Grupo

Cada grupo tiene su propia card con:

- **Precio actual** con flecha change %
- **Luz de estado**: verde = operativo, amarillo = warning, rojo = error/off
- **Señales recientes**: últimas 3 señales con estado
- **Performance**: P/L día, tasa de acierto del día
- **Actualizar**: botón pull-to-refresh manual

#### Sidebar Navegación

- Pestañas por grupo: Crypto, Memecoins, Futuros, Metales
- Filtro por activo específico
- Configuración de umbrales de señal
- Toggle modo shadow/real

#### Nav Móvil

- Igual que la sesión 03: barra inferior ultra-compacta
- En modo dashboard, la nav móvil permanece fija en la base

## Flujo de Datos en Dashboard

```mermaid
sequenceDiagram
    participant User as Trader
    participant WS as WebSocket Client
    participant BE as Backend/Python
    participant DB as SQLite
    
    User->>WS: Suscribirse a activos
    WS->>BE: Solicitar datos de mercado
    BE->>Data_Sources: Yahoo/Binance/CoinGecko
    Data_Sources-->>BE: Velas/tickers
    BE->>WS: Enviar JSON normalizado
    WS-->>User: Actualizar dashboard en tiempo real
    User->>WS: Cambiar filtro/grupo
    WS->>BE: Nueva suscripción
    BE->>DB: Guardar historial señales
    DB-->>BE: Datos históricos
    BE->>WS: Datos pasados para contexto
```

## Luces/Estados Visuales

Colores consistentes con tema Matrix Green:

| Estado | Color | Significado |
|--------|-------|-------------|
| Luces verdes | `#00FF41` | Mercado activo, señales verdes |
| Luces amarillas | `#FFB454` | Advertencia, baja volatilidad |
| Luces rojas | `#FF0000` | Mercado cerrado, error, modo shadow |
| Texto secundario | `#008F11` | Información complementaria |

## Responsividad

- **Desktop (≥1024px)**: Dashboard completo, 4 cards por grupo, sidebar fijo
- **Tablet (768-1023px)**: 2 cards por fila, sidebar colapsable
- **Móvil (<768px)**: 1 card por fila, nav móvil barra inferior, modo simplificado

## Próximos Pasos

- Implementar conexiones WebSocket reales con Yahoo Finance
- Conectar con motor de señales (sesión 05)
- Animaciones de entrada/salida de datos
- Guardar preferencias de usuario en localStorage
- Exportar datos a CSV/JSON