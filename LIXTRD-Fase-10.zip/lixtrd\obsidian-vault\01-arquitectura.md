# 01 - Arquitectura del Sistema LIXTRD Mark II

## Capas del Sistema

Presentación (React + Vite) -> Lógica de Negocio -> Datos y APIs -> Base de Datos SQLite

## 1. Presentación (Frontend)

- Framework: React 18+ con TypeScript
- Build: Vite 5+ (hot reload instantáneo)
- Ruteo: React Router DOM
- Estilos: CSS personalizado con tema Matrix Green
- Componente principal: src/App.tsx (layout: Sidebar + Content)
- Nav: Barra inferior móvil + sidebar desktop

## 2. Lógica de Negocio

- Motor de decisiones: Reglas expertas + estadística + IA híbrida
- Gestión de estado: useState, useLocalStorageState hooks
- Integración de tema: useTheme hook (toggler light/dark)
- Validación de formularios: Yup o Zod

## 3. Datos y APIs

- Yahoo Finance: WebSocket + REST para velas en tiempo real
- Binance API: Para criptomonedas (WS y REST)
- CoinGecko: Precios base y metadata
- Proveedores de futuros: Datos de índices y commodities
- Normalización de datos: Formato de velas unificado

## 4. Base de Datos

- SQLite (data/auditoria.db): Persistencia completa
- Tablas principales: signals, decisions, markets, audit_log
- ORM lightweight: better-sqlite3 o sqlite3 npm package

## Flujo de Datos

User -> Frontend -> Backend -> SQLite -> Frontend -> User

## Módulos Principales (Mapa del Repo)

Based on rumbocrp/LIXTRD structure:

sistema_luces/

├── application/     # Casos de uso (shadow, replay, query)
├── config/          # Configuraciones multi-activo
├── domain/          # Modelos de dominio y contratos
├── feed/            # Ingesta de datos (Yahoo, WebSocket)
├── learning/        # Motor de Inteligencia Artificial
├── policy/          # Policy Engine y reglas de decisión
├── presentation/    # Vistas y presentadores (UI)
├── quant/           # Indicadores y microestructura
├── simulation/      # Simulación de órdenes
├── storage/         # Persistencia SQLite
├── ui/              # Servidor Web y Dashboard
├── sources/         # Fuentes de datos externas
├── scripts/         # Scripts de ejecución
│   ├── ejecutar_yahoo_sp500.py
│   ├── iniciar_servidor_luces.py
│   └── verificar_documentacion.py
├── data/            # Auditoría DB (auto-generada)
├── docs/            # Documentación técnica y specs
├── tests/           # Suite de pruebas unitarias
├── pyproject.toml   # Configuración del proyecto
└── README.md        # Este manual

## Estado de Componentes Actuales

- src/index.css: Base lista, necesita --text fix en oscuro
- src/App.tsx: Estructura OK, Sidebar + Content layout
- src/components/Sidebar.tsx: Listo, necesita clase sidebar__nav fix
- src/main.tsx: Listo, order import critical
- Tema visual: Parcial, Matrix Green override en desarrollo
- Nav móvil: Planificado, guía LEGO completada (ver tutorial)

## Próximos Pasos de Arquitectura

1. Definir tipos TypeScript para todos los activos (crypto, futuros, metales)
2. Corregir sidebar--nav → sidebar__nav en Sidebar.tsx
3. Aplicar tema Matrix Green completo (theme-matrix.css)
4. Integrar Yahoo Finance WebSocket feed
5. Configurar Schema SQLite para auditoría completa