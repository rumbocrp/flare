# 03 - Nav Móvil Ultra-Compacta LIXTRD Mark II

## Objetivo

Diseñar y construir la navegación móvil con barra inferior ultra-compacta: 4 íconos visibles + botón "Más" (⋮) que abre un popover compacto con "System Settings". Breakpoints: <561px (4+⋮), 561-720px (5 íconos), ≥721px (sidebar desktop, nav oculta).

## Problema Diagnóstico

En móvil, los 5 botones del sidebar se apilaban en columna y la barra superior crecía hasta ~290px. Causas raíz:

- `Sidebar.tsx:28` usaba `className='sidebar--nav'` pero el CSS mira `.sidebar__nav` (clase rota)
- `Sidebar.css:51,56,80` usaba selectores rotos: `.sidebar.icon`, `.sidebar.footer`, `.sidebar.link` (punto simple en vez de doble guion bajo BEM)
- Media query móvil en `Sidebar.css:63-88` nunca aplicó `flex-direction: row` por los selectores fallidos

## Solución Aplicada

### Micro-edits en `src/components/Sidebar.tsx` (3 cambios):

1. Agregar importación: `import { MobileNav } from './MobileNav'`
2. Corregir clase: `sidebar--nav` → `sidebar__nav` en la línea 28
3. Insertar `<MobileNav activePage={activePage} onNavigate={onNavigate} />` antes del footer

### Archivo nuevo: `src/components/MobileNav.tsx`

Componente React con `useState` que renderiza:
- Barra inferior con 5 botones (en pantallas suficientes anchas)
- Botón ⋮ "Más" que toggla el popover
- Popover compacto con "System Settings"

### Archivo nuevo: `src/components/MobileNav.css`

Estilos ultra-compactos con breakpoints:

- `< 561px`: 4 botones visibles + ⋮ "Más" que abre popover
- `561px - 720px`: 5 botones en barra, ⋮ y popover ocultos
- `≥ 721px`: nav oculta, sidebar desktop visible

## Flujo Visual

Móvil 390px: 4 íconos + ⋮ → popover con System Settings
Móvil 707px: 5 íconos en barra, sin ⋮
Escritorio: sidebar lateral, nav inferior oculta

## Próximos Pasos

- Probar en dispositivos reales o Chrome DevTools
- Verificar animación popover y interacción aria-expanded
- Combinar con tema Matrix Green para colores consistentes