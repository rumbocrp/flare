# 09 - Futuros e Índices LIXTRD Mark II

## Objetivo

Extender la plataforma para operar futuros de índices (S&P 500, NASDAQ) y futuros de commodities, con horarios de mercado diferenciados, multiplicadores (multipliers) y especificación de contratos diferida.

## Futuros de Índices

### S&P 500 (US500)

- **Symbol**: US500, ES, SP500
- **Exchange**: CME (Chicago Mercantile Exchange)
- **Multiplier**: $50 por punto (ES contract)
- **Horario de trading**: 17:30 - 16:00 CT (domingo - viernes, casi 24h con pause 18:00-18:30)
- **Tick size**: 0.25 puntos = $12.50
- **Horarios de pausa**: 18:00-18:30 CT (clearing)

### NASDAQ Futures (NAS100)

- **Symbol**: NAS100, NQ
- **Exchange**: CME
- **Multiplier**: $20 por punto (NQ contract)
- **Horario**: Similar a S&P 500, 17:30 - 16:00 CT
- **Características**: Mayor volatilidad que S&P 500, tecnológicas peso

### Dow Jones (YM)

- **Symbol**: YM
- **Exchange**: CME
- **Multiplier**: $5 por punto
- **Horario**: 17:30 - 16:00 CT

## Futuros de Commodities

### Oro (GC / XAUUSD Futuros)

- **Symbol**: GC, Gold Futures
- **Exchange**: CME
- **Multiplier**: $100 por onza troy
- **Tick size**: 0.10 onzas = $10
- **Horario**: 17:00 - 16:00 CT (casi 23h, pause 18:00-18:30)
- **Factores**: Dólar fuerte, tipos de interés, tensiones geopolíticas

### Petróleo Crudo (CL / WTI)

- **Symbol**: CL, WTI Futures
- **Exchange**: CME
- **Multiplier**: $1000 por barril
- **Tick size**: 0.01 barril = $10
- **Horario**: 17:00 - 16:00 CT (casi 23h)
- **Factores**: OPEP+, inventarios API, tensiones mediooriente

### Plata (SI)

- **Symbol**: SI, Silver Futures
- **Multiplier**: $50 por onza
- **Relación**: Generalmente sigue oro con delta variable

## Integración de Datos

### Yahoo Finance (principal)

- Símbolos: ^GSPC (S&P 500), ^IXIC (NASDAQ), ^DJI (Dow)
- Datos de velas cada 1 minuto durante horario de trading
- Fallback a horarios de mercado definitivos

### Proveedores Especializados

- **CME Direct**: Datos oficiales, premium, latency baja
- **NinjaTrader data feed**: Graficos de alta calidad, horarios completos
- **Polygon.io**: Datos de futuros API, horarios definidos

## Normalización de Futuros

Cada futuro se normaliza a esquema común (sesión 04):

```json
{
  "symbol": "ES",
  "type": "future",
  "underlying": "S&P 500",
  "expiry": "2024-12-20",  // fecha vencimiento
  "multiplier": 50,
  "tick_value": 12.5,
  "price": 5200.25,
  "change": +15.50,
  "changePercent": +0.30,
  "session": "day",  // day / night / globex
  "hours": "17:30-16:00 CT",
  "source": "cme|yahoo|polygon"
}
```

## Gestión de Sesiones de Mercado

### Estados de Mercado

| Estado | Significado | Acción del Motor |
|--------|-------------|------------------|
| `open` | Mercado operativo actual | Señales normales |
| `night` | Sesión nocturna (Globex) | Señales con filtros nocturnos |
| `pause` | Pausa técnica (18:00-18:30) | Sin señales nuevas |
| `close` | Mercado cerrado | Sin operaciones, datos históricos |
| `holiday` | Festivo de mercado | Sin operaciones, info educativa |

### Filtros por Sesión

- **Horario de día**: Todas las estrategias activas
- **Horario nocturno**: Solo tendencias largas, sin scalping
- **Pausa técnica**: Reinicio de contadores, limpieza de estados
- **Feriados**: Información al usuario, modo educational

## Integración con Motor de Señales

El motor adapta sus parámetros automáticamente por tipo de futuro:

### Parámetros por Futuro

| Futuro | Min Confianza | Tamaño Lote | Stop Loss Base | Take Profit Objetivo |
|--------|--------------|-------------|----------------|----------------------|
| S&P 500 (ES) | 0.5 | 1 contrato | 12 pts | 20 pts |
| NASDAQ (NQ) | 0.55 | 1 contrato | 15 pts | 30 pts |
| Oro (GC) | 0.45 | 1 contrato | 80 $/oz | 150 $/oz |
| Petróleo (CL) | 0.5 | 1 contrato | 150 $ | 300 $ |

### Adaptación de Reglas

- **Breakout**: Filtros más estrictos en futuros nocturnos
- **Trend following**: Más permisivo en sesiones de alta volatilidad
- **Mean reversion**: Solo en sesiones de día, no nocturno
- **Volatility adjustment**: ATR-based position sizing por futuro

## Riesgos Específicos Futuros

1. **Leverage riesgo**: Multiplicadores altos amplifican ganancias y pérdidas
2. **Expiración de contrato**: Near-month vs far-month tienen volatilidad diferente
3. **Liquidez en cierre**: Menor volumen último día de vencimiento
4. **Gap apertura**: Futures pueden abrir gap vs cierre anterior domingo
5. **Tipo de cambio USD**: Futuros dolarizados siempre tienen exposición cambiaria

## Próximos Pasos

- Implementar conectores CME/Yahoo para futuros de índices y commodities
- Agregar selector de vencimiento de contrato en UI
- Configurar horarios de mercado automáticos por símbolo
- Integrar márgenes y requisitos de capital en dashboard
- Conectar con gestión de riesgo (sesión 07) para exposición por futuro