# 02 - Tema Matrix Green LIXTRD Mark II

## Objetivo

Implementar el tema visual Matrix Green en toda la aplicación React, con tokens oscuros exactos y variante pálida accesible para modo claro, asegurando que el toggler de tema sea significativo y coherente.

## Problema Diagnóstico

El tema claro no era coherente: al cambiar a modo light, el fondo de body se aclaraba, pero la sidebar, tarjetas, botones, segmented control y formularios seguían con colores hex oscuros hardcodeados que no respondían al tema. Causas raíz:

- `--text-subtle: #6hb7389` en `index.css:16` (hex inválido, declaración descartada)
- `--text` no definido en `:root` oscuro de `index.css`
- Componentes con colores hex fijos que ignoran `data-theme='light'`

## Solución Aplicada

Archivo nuevo: `src/theme-matrix.css` con:

### Tokens oscuros (paleta exacta 21st.dev)

```
--background: #000000
--foreground: #00FF41
--card: #050505
--border: #003B00
--primary: #00FF41
--secondary: #003B00
--muted: #001A00
--muted-foreground: #008F11
--destructive: #FF0000
```

### Tokens claros (variante pálida accesible)

```
--background: #F0FFF4
--foreground: #006400
--card: #E8FFF0
--border: #69E38A
--primary: #00AA33
--secondary: #55D27A
```

### Sobreescritura de componentes clave

Todos los componentes ahora usan `var(--surface)`, `var(--border)`, `var(--text)` en lugar de hex hardcodeados, con reglas `!important` para ganar cascada. Cargado como última importación en `main.tsx` después de `import App from './App.tsx'` y `import './index.css'`.

## Breakpoints y Responsividad

El tema funciona en conjunto con el hook `useTheme` de `src/hooks/useTheme` y las clases `data-theme='light'` / `data-theme='dark'` en el elemento html.

## Próximos Pasos

- Validar en `npm run dev` modo claro y oscuro
- Verificar que todos los componentes (cards, buttons, forms, tables) respeten las variables
- Asegurar breakpoints responsivos en conjunto con nav móvil