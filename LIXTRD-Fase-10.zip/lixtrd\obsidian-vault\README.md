# LIXTRD Mark II — Tutorial Progressivo

Vault for the hand-made, enhanced, and expanded LIXTRD platform.

## Session Index

00-visión-general.md → 01-arquitectura.md → 02-tema-matrix.md → 03-nav-movil.md → 04-datos.md → 05-motor-señales.md → 06-dashboard.md → 07-riesgo-auditoria.md → 08-memecoins.md → 09-futuros-indices.md → 10-metales.md → 11-despliegue.md → 12-roadmap.md

## State

| Session | Description | Status |
|---------|-------------|--------|
| 00 | Visión General del Proyecto | pending |
| 01 | Arquitectura del Sistema | pending |
| 02 | Tema Matrix Green | pending |
| 03 | Nav Móvil Ultra-Compacta | pending |
| 04 | Ingestión de Datos Multi-Activo | pending |
| 05 | Motor de Señales e IA Híbrida | pending |
| 06 | Dashboard Web en Tiempo Real | pending |
| 07 | Gestión de Riesgo y Auditoría | pending |
| 08 | Expansión a Memecoins | pending |
| 09 | Futuros e Índices | pending |
| 10 | Metales Preciosos | pending |
| 11 | Despliegue y Producción | pending |
| 12 | Roadmap y Futuro | pending |

## Startup

Open Obsidian and point to: `C:\Users\Bitbase\OneDrive\Documents\BITBASE\FLARE\lixtrd\obsidian-vault`

Begin with session 00.